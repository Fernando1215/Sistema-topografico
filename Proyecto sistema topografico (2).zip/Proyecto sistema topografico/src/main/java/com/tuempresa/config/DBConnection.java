package com.tuempresa.config;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
public class DBConnection {
    private static final String SUPABASE_URL =
            "https://eobnwfvgrwtxoojchccs.supabase.co";
    private static final String SUPABASE_KEY =
            "sb_publishable_UcT3pYh6OhMYSUrio4mcfQ_gTjPx2oi";
    private static final HttpClient CLIENT = HttpClient.newHttpClient();
    public static String get(String tabla) throws Exception {
        String url = SUPABASE_URL + "/rest/v1/" + tabla;
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer " + SUPABASE_KEY)
                .header("Content-Type", "application/json")
                .GET()
                .build();
        HttpResponse<String> response =
                CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
        return response.body();
    }
    public static String getUrl(String url) throws Exception {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer " + SUPABASE_KEY)
                .header("Content-Type", "application/json")
                .GET()
                .build();
        HttpResponse<String> response =
                CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
        return response.body();
    }
    public static String post(String tabla, String json) throws Exception {
        String url = SUPABASE_URL + "/rest/v1/" + tabla;
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer " + SUPABASE_KEY)
                .header("Content-Type", "application/json")
                .header("Prefer", "return=representation")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();
        HttpResponse<String> response =
                CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
        return response.body();
    }
    public static String patch(String tablaConFiltro, String json) throws Exception {
        String url = SUPABASE_URL + "/rest/v1/" + tablaConFiltro;
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer " + SUPABASE_KEY)
                .header("Content-Type", "application/json")
                .header("Prefer", "return=representation")
                .method("PATCH", HttpRequest.BodyPublishers.ofString(json))
                .build();
        HttpResponse<String> response =
                CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
        return response.body();
    }
    public static String delete(String tablaConFiltro) throws Exception {
        String url = SUPABASE_URL + "/rest/v1/" + tablaConFiltro;
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer " + SUPABASE_KEY)
                .header("Content-Type", "application/json")
                .DELETE()
                .build();
        HttpResponse<String> response =
                CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
        return response.body();
    }
    public static void uploadFile(String bucket, String path, byte[] contenido, String contentType) throws Exception {
        String url = SUPABASE_URL + "/storage/v1/object/" + bucket + "/" + path;
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer " + SUPABASE_KEY)
                .header("Content-Type", contentType)
                .POST(HttpRequest.BodyPublishers.ofByteArray(contenido))
                .build();
        HttpResponse<String> response =
                CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() >= 300) {
            throw new Exception("Error al subir archivo: " + response.body());
        }
    }
    public static String getPublicUrl(String bucket, String path) {
        return SUPABASE_URL + "/storage/v1/object/public/" + bucket + "/" + path;
    }
}