package com.tuempresa.repository;
import com.tuempresa.config.DBConnection;
import com.tuempresa.model.Pago;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
public class PagoRepository {
    public void registrarPago(Pago p) throws Exception {
        StringBuilder json = new StringBuilder("{");
        json.append("\"cliente_id\":").append(p.getClienteId()).append(",");
        if (p.getProyectoId() != null) {
            json.append("\"proyecto_id\":").append(p.getProyectoId()).append(",");
        }
        json.append("\"monto\":").append(String.format(Locale.US, "%.2f", p.getMonto())).append(",");
        json.append("\"fecha_pago\":\"").append(p.getFechaPago()).append("\",");
        json.append("\"metodo_pago\":\"").append(escapeJson(p.getMetodoPago())).append("\",");
        json.append("\"estado\":\"").append(escapeJson(p.getEstado())).append("\",");
        json.append("\"concepto\":\"").append(escapeJson(p.getConcepto())).append("\"");
        json.append("}");
        String body = DBConnection.post("pago", json.toString());
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
    }
    public List<Pago> obtenerTodos() throws Exception {
        String body = DBConnection.get("pago?select=*&order=fecha_pago.desc");
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
        return parsePagos(body);
    }
    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
    private boolean esError(String body) {
        return body != null && body.trim().startsWith("{") && body.contains("\"message\"");
    }
    private List<String> splitJsonArray(String json) {
        List<String> objetos = new ArrayList<>();
        int depth = 0;
        boolean enComillas = false;
        StringBuilder actual = new StringBuilder();
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) enComillas = !enComillas;
            if (!enComillas) {
                if (c == '{') depth++;
                if (c == '}') depth--;
            }
            if (depth > 0 || (depth == 0 && c == '}')) actual.append(c);
            if (depth == 0 && c == '}') {
                objetos.add(actual.toString());
                actual = new StringBuilder();
            }
        }
        return objetos;
    }
    private List<Pago> parsePagos(String json) {
        List<Pago> lista = new ArrayList<>();
        for (String obj : splitJsonArray(json)) {
            Pago p = new Pago();
            p.setId(Long.parseLong(extractField(obj, "id")));
            p.setClienteId(Long.parseLong(extractField(obj, "cliente_id")));
            String proyStr = extractField(obj, "proyecto_id");
            p.setProyectoId(proyStr.isEmpty() ? null : Long.parseLong(proyStr));
            String montoStr = extractField(obj, "monto");
            p.setMonto(montoStr.isEmpty() ? 0 : Double.parseDouble(montoStr));
            p.setFechaPago(extractField(obj, "fecha_pago"));
            p.setMetodoPago(extractField(obj, "metodo_pago"));
            p.setEstado(extractField(obj, "estado"));
            p.setConcepto(extractField(obj, "concepto"));
            lista.add(p);
        }
        return lista;
    }
    private String extractField(String json, String field) {
        String keyStr = "\"" + field + "\":\"";
        int start = json.indexOf(keyStr);
        if (start != -1) {
            start += keyStr.length();
            int end = json.indexOf("\"", start);
            return json.substring(start, end);
        }
        String keyLiteral = "\"" + field + "\":";
        start = json.indexOf(keyLiteral);
        if (start == -1) return "";
        start += keyLiteral.length();
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        String val = json.substring(start, end).trim();
        return val.equals("null") ? "" : val;
    }
}