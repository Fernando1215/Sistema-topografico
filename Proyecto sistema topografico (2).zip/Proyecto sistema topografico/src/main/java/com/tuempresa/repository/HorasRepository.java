package com.tuempresa.repository;

import com.tuempresa.config.DBConnection;
import com.tuempresa.model.RegistroHoras;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class HorasRepository {

    public void registrarHoras(long personalId, Long proyectoId, String fecha,
                               double horas, String descripcion) throws Exception {
        StringBuilder json = new StringBuilder("{");
        json.append("\"personal_id\":").append(personalId).append(",");
        if (proyectoId != null) {
            json.append("\"proyecto_id\":").append(proyectoId).append(",");
        }
        json.append("\"fecha\":\"").append(fecha).append("\",");
        json.append("\"horas\":").append(String.format(Locale.US, "%.2f", horas)).append(",");
        json.append("\"descripcion\":\"").append(escapeJson(descripcion)).append("\"");
        json.append("}");
        String body = DBConnection.post("registro_horas", json.toString());
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
    }

    /** Horas que todavía no se han pagado, con fecha igual o anterior a hastaFecha (yyyy-MM-dd). */
    public List<RegistroHoras> obtenerPendientes(String hastaFecha) throws Exception {
        String body = DBConnection.get("registro_horas?pago_personal_id=is.null&fecha=lte." + hastaFecha
                + "&select=id,personal_id,fecha,horas&order=fecha.asc");
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
        List<RegistroHoras> lista = new ArrayList<>();
        for (String obj : splitJsonArray(body)) {
            RegistroHoras r = new RegistroHoras();
            r.setId(Long.parseLong(extractField(obj, "id")));
            r.setPersonalId(Long.parseLong(extractField(obj, "personal_id")));
            r.setFecha(extractField(obj, "fecha"));
            String horasStr = extractField(obj, "horas");
            r.setHoras(horasStr.isEmpty() ? 0 : Double.parseDouble(horasStr));
            lista.add(r);
        }
        return lista;
    }

    /**
     * Paga las horas indicadas de un trabajador. La función SQL pagar_horas_personal hace todo
     * en una sola operación: calcula el monto (horas x tarifa), crea el pago y marca las horas
     * como pagadas. Si algo falla, no se guarda nada.
     */
    public void pagarHoras(long personalId, List<Long> registroIds, String fechaPago) throws Exception {
        StringBuilder ids = new StringBuilder();
        for (int i = 0; i < registroIds.size(); i++) {
            if (i > 0) ids.append(",");
            ids.append(registroIds.get(i));
        }
        String json = "{\"p_personal_id\":" + personalId
                + ",\"p_registro_ids\":[" + ids + "]"
                + ",\"p_fecha\":\"" + fechaPago + "\"}";
        String body = DBConnection.post("rpc/pagar_horas_personal", json);
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
    }

    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private boolean esError(String body) {
        return body != null && body.trim().startsWith("{") && body.contains("\"message\"");
    }

    private List<String> splitJsonArray(String json) {
        List<String> objetos = new ArrayList<>();
        int depth = 0;
        boolean enComillas = false;
        StringBuilder actual = new StringBuilder();
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) enComillas = !enComillas;
            if (!enComillas) {
                if (c == '{') depth++;
                if (c == '}') depth--;
            }
            if (depth > 0 || (depth == 0 && c == '}')) actual.append(c);
            if (depth == 0 && c == '}') {
                objetos.add(actual.toString());
                actual = new StringBuilder();
            }
        }
        return objetos;
    }

    private String extractField(String json, String field) {
        String keyStr = "\"" + field + "\":\"";
        int start = json.indexOf(keyStr);
        if (start != -1) {
            start += keyStr.length();
            int end = json.indexOf("\"", start);
            return json.substring(start, end);
        }
        String keyLiteral = "\"" + field + "\":";
        start = json.indexOf(keyLiteral);
        if (start == -1) return "";
        start += keyLiteral.length();
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        String val = json.substring(start, end).trim();
        return val.equals("null") ? "" : val;
    }
}
