package com.tuempresa.repository;
import com.tuempresa.config.DBConnection;
import com.tuempresa.model.Documento;
import java.util.ArrayList;
import java.util.List;
public class DocumentoRepository {
    public void registrarDocumento(Documento d) throws Exception {
        String json = String.format(
                "{\"proyecto_id\":%d,\"nombre_archivo\":\"%s\",\"url\":\"%s\"}",
                d.getProyectoId(), escapeJson(d.getNombreArchivo()), escapeJson(d.getUrl())
        );
        String body = DBConnection.post("documento", json);
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
    }
    public List<Documento> obtenerPorProyecto(long proyectoId) throws Exception {
        String body = DBConnection.get("documento?proyecto_id=eq." + proyectoId + "&select=*&order=fecha_subida.desc");
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
        return parseDocumentos(body);
    }
    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
    private boolean esError(String body) {
        return body != null && body.trim().startsWith("{") && body.contains("\"message\"");
    }
    private List<String> splitJsonArray(String json) {
        List<String> objetos = new ArrayList<>();
        int depth = 0;
        boolean enComillas = false;
        StringBuilder actual = new StringBuilder();
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) enComillas = !enComillas;
            if (!enComillas) {
                if (c == '{') depth++;
                if (c == '}') depth--;
            }
            if (depth > 0 || (depth == 0 && c == '}')) actual.append(c);
            if (depth == 0 && c == '}') {
                objetos.add(actual.toString());
                actual = new StringBuilder();
            }
        }
        return objetos;
    }
    private List<Documento> parseDocumentos(String json) {
        List<Documento> lista = new ArrayList<>();
        for (String obj : splitJsonArray(json)) {
            Documento d = new Documento();
            d.setId(Long.parseLong(extractField(obj, "id")));
            d.setProyectoId(Long.parseLong(extractField(obj, "proyecto_id")));
            d.setNombreArchivo(extractField(obj, "nombre_archivo"));
            d.setUrl(extractField(obj, "url"));
            d.setFechaSubida(extractField(obj, "fecha_subida"));
            lista.add(d);
        }
        return lista;
    }
    private String extractField(String json, String field) {
        String keyStr = "\"" + field + "\":\"";
        int start = json.indexOf(keyStr);
        if (start != -1) {
            start += keyStr.length();
            int end = json.indexOf("\"", start);
            return json.substring(start, end);
        }
        String keyLiteral = "\"" + field + "\":";
        start = json.indexOf(keyLiteral);
        if (start == -1) return "";
        start += keyLiteral.length();
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        String val = json.substring(start, end).trim();
        return val.equals("null") ? "" : val;
    }
}