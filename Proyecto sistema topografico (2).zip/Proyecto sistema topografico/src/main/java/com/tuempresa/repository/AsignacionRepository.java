package com.tuempresa.repository;
import com.tuempresa.config.DBConnection;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
public class AsignacionRepository {
    public Set<Long> obtenerAsignados(long proyectoId) throws Exception {
        String body = DBConnection.get("proyecto_personal?proyecto_id=eq." + proyectoId + "&select=personal_id");
        Set<Long> ids = new HashSet<>();
        for (String obj : splitJsonArray(body)) {
            String idStr = extractField(obj, "personal_id");
            if (!idStr.isEmpty()) ids.add(Long.parseLong(idStr));
        }
        return ids;
    }
    public void guardarAsignaciones(long proyectoId, Set<Long> nuevosIds) throws Exception {
        Set<Long> actuales = obtenerAsignados(proyectoId);
        for (Long personalId : nuevosIds) {
            if (!actuales.contains(personalId)) {
                String json = "{\"proyecto_id\":" + proyectoId + ",\"personal_id\":" + personalId + "}";
                DBConnection.post("proyecto_personal", json);
            }
        }
        for (Long personalId : actuales) {
            if (!nuevosIds.contains(personalId)) {
                DBConnection.delete("proyecto_personal?proyecto_id=eq." + proyectoId + "&personal_id=eq." + personalId);
            }
        }
    }
    private List<String> splitJsonArray(String json) {
        List<String> objetos = new ArrayList<>();
        int depth = 0;
        boolean enComillas = false;
        StringBuilder actual = new StringBuilder();
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) enComillas = !enComillas;
            if (!enComillas) {
                if (c == '{') depth++;
                if (c == '}') depth--;
            }
            if (depth > 0 || (depth == 0 && c == '}')) actual.append(c);
            if (depth == 0 && c == '}') {
                objetos.add(actual.toString());
                actual = new StringBuilder();
            }
        }
        return objetos;
    }
    private String extractField(String json, String field) {
        String keyLiteral = "\"" + field + "\":";
        int start = json.indexOf(keyLiteral);
        if (start == -1) return "";
        start += keyLiteral.length();
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        String val = json.substring(start, end).trim();
        return val.equals("null") ? "" : val;
    }
}