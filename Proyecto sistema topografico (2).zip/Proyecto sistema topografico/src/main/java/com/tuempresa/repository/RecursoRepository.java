package com.tuempresa.repository;

import com.tuempresa.config.DBConnection;
import com.tuempresa.model.Recurso;

import java.util.ArrayList;
import java.util.List;

public class RecursoRepository {

    public List<Recurso> obtenerTodos() throws Exception {
        String body = DBConnection.get("recurso?select=*,proyecto(nombre)&order=nombre.asc");
        if (esError(body)) throw new Exception("Error de Supabase: " + body);
        return parseRecursos(body);
    }

    public void registrarRecurso(Recurso r) throws Exception {
        StringBuilder json = new StringBuilder("{");
        json.append("\"proyecto_id\":").append(r.getProyectoId()).append(",");
        json.append("\"nombre\":").append(texto(r.getNombre())).append(",");
        json.append("\"tipo\":").append(texto(r.getTipo())).append(",");
        json.append("\"codigo\":").append(textoONulo(r.getCodigo())).append(",");
        json.append("\"descripcion\":").append(textoONulo(r.getDescripcion()));
        if (r.getFechaAdquisicion() != null && !r.getFechaAdquisicion().isEmpty()) {
            json.append(",\"fecha_adquisicion\":").append(texto(r.getFechaAdquisicion()));
        }
        json.append("}");
        validarRespuesta(DBConnection.post("recurso", json.toString()));
    }

    public void actualizarRecurso(Recurso r) throws Exception {
        String json = "{"
                + "\"proyecto_id\":" + r.getProyectoId() + ","
                + "\"nombre\":" + texto(r.getNombre()) + ","
                + "\"tipo\":" + texto(r.getTipo()) + ","
                + "\"codigo\":" + textoONulo(r.getCodigo()) + ","
                + "\"descripcion\":" + textoONulo(r.getDescripcion()) + ","
                + "\"estado\":" + texto(r.getEstado())
                + "}";
        validarRespuesta(DBConnection.patch("recurso?id=eq." + r.getId(), json));
    }

    private void validarRespuesta(String body) throws Exception {
        if (!esError(body)) return;
        if (body.contains("23505") || body.contains("duplicate key")) {
            throw new Exception("Ya existe un recurso con ese código.");
        }
        throw new Exception("Error de Supabase: " + body);
    }

    private String texto(String value) {
        return "\"" + escapeJson(value) + "\"";
    }

    private String textoONulo(String value) {
        if (value == null || value.trim().isEmpty()) return "null";
        return texto(value.trim());
    }

    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    private boolean esError(String body) {
        return body != null && body.trim().startsWith("{") && body.contains("\"message\"");
    }

    private List<String> splitJsonArray(String json) {
        List<String> objetos = new ArrayList<>();
        int depth = 0;
        boolean enComillas = false;
        StringBuilder actual = new StringBuilder();
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) enComillas = !enComillas;
            if (!enComillas) {
                if (c == '{') depth++;
                if (c == '}') depth--;
            }
            if (depth > 0 || (depth == 0 && c == '}')) actual.append(c);
            if (depth == 0 && c == '}') {
                objetos.add(actual.toString());
                actual = new StringBuilder();
            }
        }
        return objetos;
    }

    private List<Recurso> parseRecursos(String json) {
        List<Recurso> lista = new ArrayList<>();
        for (String obj : splitJsonArray(json)) {
            Recurso r = new Recurso();
            r.setId(Long.parseLong(extractField(obj, "id")));
            r.setProyectoId(Long.parseLong(extractField(obj, "proyecto_id")));
            r.setNombre(extractField(obj, "nombre"));
            r.setTipo(extractField(obj, "tipo"));
            r.setCodigo(extractField(obj, "codigo"));
            r.setDescripcion(extractField(obj, "descripcion"));
            r.setEstado(extractField(obj, "estado"));
            r.setFechaAdquisicion(extractField(obj, "fecha_adquisicion"));
            r.setActivo("true".equals(extractField(obj, "activo")));

            int inicioProyecto = obj.indexOf("\"proyecto\":{");
            if (inicioProyecto != -1) {
                r.setNombreProyecto(extractField(obj.substring(inicioProyecto), "nombre"));
            }
            lista.add(r);
        }
        return lista;
    }

    private String extractField(String json, String field) {
        String keyStr = "\"" + field + "\":\"";
        int start = json.indexOf(keyStr);
        if (start != -1) {
            start += keyStr.length();
            int end = json.indexOf("\"", start);
            return json.substring(start, end);
        }
        String keyLiteral = "\"" + field + "\":";
        start = json.indexOf(keyLiteral);
        if (start == -1) return "";
        start += keyLiteral.length();
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        String val = json.substring(start, end).trim();
        return val.equals("null") ? "" : val;
    }
}
