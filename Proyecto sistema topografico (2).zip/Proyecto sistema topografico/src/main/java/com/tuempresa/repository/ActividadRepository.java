package com.tuempresa.repository;
import com.tuempresa.config.DBConnection;
import com.tuempresa.model.Actividad;
import java.util.ArrayList;
import java.util.List;
public class ActividadRepository {
    public void registrarActividad(Actividad a) throws Exception {
        StringBuilder json = new StringBuilder("{");
        json.append("\"proyecto_id\":").append(a.getProyectoId()).append(",");
        json.append("\"nombre\":\"").append(escapeJson(a.getNombre())).append("\",");
        json.append("\"descripcion\":\"").append(escapeJson(a.getDescripcion())).append("\",");
        json.append("\"estado\":\"").append(escapeJson(a.getEstado())).append("\"");
        if (a.getFecha() != null && !a.getFecha().isEmpty()) {
            json.append(",\"fecha\":\"").append(a.getFecha()).append("\"");
        }
        if (a.getResponsableId() != null) {
            json.append(",\"responsable_id\":").append(a.getResponsableId());
        }
        json.append("}");
        String body = DBConnection.post("actividad", json.toString());
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
    }
    public List<Actividad> obtenerPorProyecto(long proyectoId) throws Exception {
        String body = DBConnection.get("actividad?proyecto_id=eq." + proyectoId + "&select=*&order=fecha.asc");
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
        return parseActividades(body);
    }
    public List<Actividad> obtenerTodas() throws Exception {
        String body = DBConnection.get("actividad?select=*&order=fecha.asc");
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
        return parseActividades(body);
    }
    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
    private boolean esError(String body) {
        return body != null && body.trim().startsWith("{") && body.contains("\"message\"");
    }
    private List<String> splitJsonArray(String json) {
        List<String> objetos = new ArrayList<>();
        int depth = 0;
        boolean enComillas = false;
        StringBuilder actual = new StringBuilder();
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) enComillas = !enComillas;
            if (!enComillas) {
                if (c == '{') depth++;
                if (c == '}') depth--;
            }
            if (depth > 0 || (depth == 0 && c == '}')) actual.append(c);
            if (depth == 0 && c == '}') {
                objetos.add(actual.toString());
                actual = new StringBuilder();
            }
        }
        return objetos;
    }
    private List<Actividad> parseActividades(String json) {
        List<Actividad> lista = new ArrayList<>();
        for (String obj : splitJsonArray(json)) {
            Actividad a = new Actividad();
            a.setId(Long.parseLong(extractField(obj, "id")));
            a.setProyectoId(Long.parseLong(extractField(obj, "proyecto_id")));
            a.setNombre(extractField(obj, "nombre"));
            a.setDescripcion(extractField(obj, "descripcion"));
            a.setFecha(extractField(obj, "fecha"));
            a.setEstado(extractField(obj, "estado"));
            String respStr = extractField(obj, "responsable_id");
            a.setResponsableId(respStr.isEmpty() ? null : Long.parseLong(respStr));
            lista.add(a);
        }
        return lista;
    }
    private String extractField(String json, String field) {
        String keyStr = "\"" + field + "\":\"";
        int start = json.indexOf(keyStr);
        if (start != -1) {
            start += keyStr.length();
            int end = json.indexOf("\"", start);
            return json.substring(start, end);
        }
        String keyLiteral = "\"" + field + "\":";
        start = json.indexOf(keyLiteral);
        if (start == -1) return "";
        start += keyLiteral.length();
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        String val = json.substring(start, end).trim();
        return val.equals("null") ? "" : val;
    }
}