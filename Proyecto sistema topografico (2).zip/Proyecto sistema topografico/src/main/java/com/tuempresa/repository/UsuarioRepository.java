package com.tuempresa.repository;
import com.tuempresa.config.DBConnection;
import com.tuempresa.model.Usuario;
import org.mindrot.jbcrypt.BCrypt;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
public class UsuarioRepository {
    public Usuario validarLogin(String correo, String contrasena) throws Exception {
        String json = "{\"p_correo\":\"" + escapeJson(correo)
                + "\",\"p_contrasena\":\"" + escapeJson(contrasena) + "\"}";
        String body = DBConnection.post("rpc/validar_login", json);
        if (body == null || body.trim().equals("[]")) {
            return null; // correo o contraseña incorrectos, o usuario inactivo
        }
        if (body.trim().startsWith("{") && body.contains("\"message\"")) {
            throw new Exception("Error de Supabase: " + body);
        }
        Usuario usuario = new Usuario();
        usuario.setId(Long.parseLong(extractField(body, "id")));
        usuario.setCorreo(extractField(body, "correo"));
        usuario.setNombre(extractField(body, "nombre"));
        usuario.setRol(extractField(body, "rol"));
        usuario.setActivo(true);
        return usuario;
    }
    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
    private String extractField(String json, String field) {
        String keyStr = "\"" + field + "\":\"";
        int start = json.indexOf(keyStr);
        if (start != -1) {
            start += keyStr.length();
            int end = json.indexOf("\"", start);
            return json.substring(start, end);
        }
        String keyLiteral = "\"" + field + "\":";
        start = json.indexOf(keyLiteral);
        if (start == -1) return null;
        start += keyLiteral.length();
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        return json.substring(start, end).trim();
    }
}