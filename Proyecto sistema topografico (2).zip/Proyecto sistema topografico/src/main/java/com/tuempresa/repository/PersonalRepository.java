package com.tuempresa.repository;
import com.tuempresa.config.DBConnection;
import com.tuempresa.model.Personal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
public class PersonalRepository {
    public List<Personal> obtenerTodos() throws Exception {
        String body = DBConnection.get("personal?select=*&order=nombre.asc");
        if (esError(body)) throw new Exception("Error de Supabase: " + body);
        return parsePersonal(body);
    }
    public void registrarPersonal(Personal p) throws Exception {
        String json = String.format(
                "{\"nombre\":\"%s\",\"cargo\":\"%s\",\"telefono\":\"%s\",\"correo\":\"%s\"}",
                escapeJson(p.getNombre()), escapeJson(p.getCargo()),
                escapeJson(p.getTelefono()), escapeJson(p.getCorreo())
        );
        if (p.getTarifaHora() > 0) {
            json = json.substring(0, json.length() - 1)
                    + ",\"tarifa_hora\":" + String.format(Locale.US, "%.2f", p.getTarifaHora()) + "}";
        }
        String body = DBConnection.post("personal", json);
        if (esError(body)) throw new Exception("Error de Supabase: " + body);
    }
    public void actualizarTarifa(long personalId, double tarifaHora) throws Exception {
        String json = "{\"tarifa_hora\":" + String.format(Locale.US, "%.2f", tarifaHora) + "}";
        String body = DBConnection.patch("personal?id=eq." + personalId, json);
        if (esError(body)) throw new Exception("Error de Supabase: " + body);
    }
    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
    private boolean esError(String body) {
        return body != null && body.trim().startsWith("{") && body.contains("\"message\"");
    }
    private List<String> splitJsonArray(String json) {
        List<String> objetos = new ArrayList<>();
        int depth = 0;
        boolean enComillas = false;
        StringBuilder actual = new StringBuilder();
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) enComillas = !enComillas;
            if (!enComillas) {
                if (c == '{') depth++;
                if (c == '}') depth--;
            }
            if (depth > 0 || (depth == 0 && c == '}')) actual.append(c);
            if (depth == 0 && c == '}') {
                objetos.add(actual.toString());
                actual = new StringBuilder();
            }
        }
        return objetos;
    }
    private List<Personal> parsePersonal(String json) {
        List<Personal> lista = new ArrayList<>();
        for (String obj : splitJsonArray(json)) {
            Personal p = new Personal();
            p.setId(Long.parseLong(extractField(obj, "id")));
            p.setNombre(extractField(obj, "nombre"));
            p.setCargo(extractField(obj, "cargo"));
            p.setTelefono(extractField(obj, "telefono"));
            p.setCorreo(extractField(obj, "correo"));
            p.setActivo("true".equals(extractField(obj, "activo")));
            String tarifaStr = extractField(obj, "tarifa_hora");
            p.setTarifaHora(tarifaStr.isEmpty() ? 0 : Double.parseDouble(tarifaStr));
            lista.add(p);
        }
        return lista;
    }
    private String extractField(String json, String field) {
        String keyStr = "\"" + field + "\":\"";
        int start = json.indexOf(keyStr);
        if (start != -1) {
            start += keyStr.length();
            int end = json.indexOf("\"", start);
            return json.substring(start, end);
        }
        String keyLiteral = "\"" + field + "\":";
        start = json.indexOf(keyLiteral);
        if (start == -1) return "";
        start += keyLiteral.length();
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        String val = json.substring(start, end).trim();
        return val.equals("null") ? "" : val;
    }
}