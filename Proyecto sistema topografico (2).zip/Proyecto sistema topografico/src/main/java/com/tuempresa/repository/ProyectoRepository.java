package com.tuempresa.repository;
import com.tuempresa.config.DBConnection;
import com.tuempresa.model.Proyecto;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
public class ProyectoRepository {
    public List<Proyecto> obtenerTodos() throws Exception {
        String body = DBConnection.get("proyecto?select=*&order=nombre.asc");
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
        return parseProyectos(body);
    }
    public void registrarProyecto(Proyecto p) throws Exception {
        String json = toJson(p);
        String body = DBConnection.post("proyecto", json);
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
    }
    private String toJson(Proyecto p) {
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"nombre\":\"").append(escapeJson(p.getNombre())).append("\",");
        sb.append("\"descripcion\":\"").append(escapeJson(p.getDescripcion())).append("\",");
        sb.append("\"cliente_id\":").append(p.getClienteId()).append(",");
        sb.append("\"estado\":\"").append(escapeJson(p.getEstado())).append("\"");
        if (p.getFechaInicio() != null && !p.getFechaInicio().isEmpty()) {
            sb.append(",\"fecha_inicio\":\"").append(p.getFechaInicio()).append("\"");
        }
        if (p.getFechaFin() != null && !p.getFechaFin().isEmpty()) {
            sb.append(",\"fecha_fin\":\"").append(p.getFechaFin()).append("\"");
        }
        if (p.getValorTotal() > 0) {
            sb.append(",\"valor_total\":").append(String.format(Locale.US, "%.2f", p.getValorTotal()));
        }
        sb.append("}");
        return sb.toString();
    }
    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
    private boolean esError(String body) {
        return body != null && body.trim().startsWith("{") && body.contains("\"message\"");
    }
    private List<String> splitJsonArray(String json) {
        List<String> objetos = new ArrayList<>();
        int depth = 0;
        boolean enComillas = false;
        StringBuilder actual = new StringBuilder();
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) enComillas = !enComillas;
            if (!enComillas) {
                if (c == '{') depth++;
                if (c == '}') depth--;
            }
            if (depth > 0 || (depth == 0 && c == '}')) actual.append(c);
            if (depth == 0 && c == '}') {
                objetos.add(actual.toString());
                actual = new StringBuilder();
            }
        }
        return objetos;
    }
    private List<Proyecto> parseProyectos(String json) {
        List<Proyecto> lista = new ArrayList<>();
        for (String obj : splitJsonArray(json)) {
            Proyecto p = new Proyecto();
            p.setId(Long.parseLong(extractField(obj, "id")));
            p.setNombre(extractField(obj, "nombre"));
            p.setDescripcion(extractField(obj, "descripcion"));
            String clienteIdStr = extractField(obj, "cliente_id");
            p.setClienteId(clienteIdStr.isEmpty() ? 0 : Long.parseLong(clienteIdStr));
            p.setEstado(extractField(obj, "estado"));
            p.setFechaInicio(extractField(obj, "fecha_inicio"));
            p.setFechaFin(extractField(obj, "fecha_fin"));
            String valorStr = extractField(obj, "valor_total");
            p.setValorTotal(valorStr.isEmpty() ? 0 : Double.parseDouble(valorStr));
            lista.add(p);
        }
        return lista;
    }
    private String extractField(String json, String field) {
        String keyStr = "\"" + field + "\":\"";
        int start = json.indexOf(keyStr);
        if (start != -1) {
            start += keyStr.length();
            int end = json.indexOf("\"", start);
            return json.substring(start, end);
        }
        String keyLiteral = "\"" + field + "\":";
        start = json.indexOf(keyLiteral);
        if (start == -1) return "";
        start += keyLiteral.length();
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        String val = json.substring(start, end).trim();
        return val.equals("null") ? "" : val;
    }
}