package com.tuempresa.repository;
import com.tuempresa.config.DBConnection;
import com.tuempresa.model.Cliente;
import java.util.ArrayList;
import java.util.List;
public class ClienteRepository {
    public void registrarCliente(Cliente cliente) throws Exception {
        String json = toJson(cliente);
        String body = DBConnection.post("cliente", json);
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
    }
    public List<Cliente> obtenerTodos() throws Exception {
        String body = DBConnection.get("cliente?select=*&order=nombre.asc");
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
        return parseClientes(body);
    }
    public void actualizarCliente(Cliente cliente) throws Exception {
        String json = toJson(cliente);
        String body = DBConnection.patch("cliente?id=eq." + cliente.getId(), json);
        if (esError(body)) {
            throw new Exception("Error de Supabase: " + body);
        }
    }
    private boolean esError(String body) {
        return body != null && body.trim().startsWith("{") && body.contains("\"message\"");
    }
    private String toJson(Cliente c) {
        return String.format(
                "{\"nombre\":\"%s\",\"documento\":\"%s\",\"telefono\":\"%s\"," +
                        "\"correo\":\"%s\",\"direccion\":\"%s\",\"tipo_cliente\":\"%s\"}",
                escapeJson(c.getNombre()), escapeJson(c.getDocumento()),
                escapeJson(c.getTelefono()), escapeJson(c.getCorreo()),
                escapeJson(c.getDireccion()), escapeJson(c.getTipoCliente())
        );
    }
    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
    // Divide el array JSON en los objetos de nivel superior, respetando comillas.
    private List<String> splitJsonArray(String json) {
        List<String> objetos = new ArrayList<>();
        int depth = 0;
        boolean enComillas = false;
        StringBuilder actual = new StringBuilder();
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) {
                enComillas = !enComillas;
            }
            if (!enComillas) {
                if (c == '{') depth++;
                if (c == '}') depth--;
            }
            if (depth > 0 || (depth == 0 && c == '}')) {
                actual.append(c);
            }

            if (depth == 0 && c == '}') {
                objetos.add(actual.toString());
                actual = new StringBuilder();
            }
        }
        return objetos;
    }
    private List<Cliente> parseClientes(String json) {
        List<Cliente> lista = new ArrayList<>();
        for (String obj : splitJsonArray(json)) {
            Cliente c = new Cliente();
            c.setId(Long.parseLong(extractField(obj, "id")));
            c.setNombre(extractField(obj, "nombre"));
            c.setDocumento(extractField(obj, "documento"));
            c.setTelefono(extractField(obj, "telefono"));
            c.setCorreo(extractField(obj, "correo"));
            c.setDireccion(extractField(obj, "direccion"));
            c.setTipoCliente(extractField(obj, "tipo_cliente"));
            lista.add(c);
        }
        return lista;
    }
    private String extractField(String json, String field) {
        String keyStr = "\"" + field + "\":\"";
        int start = json.indexOf(keyStr);
        if (start != -1) {
            start += keyStr.length();
            int end = json.indexOf("\"", start);
            return json.substring(start, end);
        }
        String keyLiteral = "\"" + field + "\":";
        start = json.indexOf(keyLiteral);
        if (start == -1) return "";
        start += keyLiteral.length();
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        String val = json.substring(start, end).trim();
        return val.equals("null") ? "" : val;
    }
}