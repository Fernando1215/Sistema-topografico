package com.tuempresa.model;
public class Documento {
    private long id;
    private long proyectoId;
    private String nombreArchivo;
    private String url;
    private String fechaSubida;
    public Documento() {
    }
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public long getProyectoId() { return proyectoId; }
    public void setProyectoId(long proyectoId) { this.proyectoId = proyectoId; }
    public String getNombreArchivo() { return nombreArchivo; }
    public void setNombreArchivo(String nombreArchivo) { this.nombreArchivo = nombreArchivo; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public String getFechaSubida() { return fechaSubida; }
    public void setFechaSubida(String fechaSubida) { this.fechaSubida = fechaSubida; }
}