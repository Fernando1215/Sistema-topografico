package com.tuempresa.model;
public class Recurso {
    private long id;
    private long proyectoId;
    private String nombreProyecto;
    private String nombre;
    private String tipo;
    private String codigo;
    private String descripcion;
    private String estado;
    private String fechaAdquisicion;
    private boolean activo;
    public Recurso() {
    }
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public long getProyectoId() { return proyectoId; }
    public void setProyectoId(long proyectoId) { this.proyectoId = proyectoId; }
    public String getNombreProyecto() { return nombreProyecto; }
    public void setNombreProyecto(String nombreProyecto) { this.nombreProyecto = nombreProyecto; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public String getFechaAdquisicion() { return fechaAdquisicion; }
    public void setFechaAdquisicion(String fechaAdquisicion) { this.fechaAdquisicion = fechaAdquisicion; }
    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
}