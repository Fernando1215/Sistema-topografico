package com.tuempresa.util;

public final class Errores {

    private Errores() {
    }

    public static String detalle(Throwable e) {
        String mensaje = e.getMessage();
        if (mensaje != null && !mensaje.isBlank()) {
            return mensaje;
        }
        return e.getClass().getSimpleName();
    }
}
