package com.tuempresa.model;

public class RegistroHoras {
    private long id;
    private long personalId;
    private String fecha;
    private double horas;

    public RegistroHoras() {
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public long getPersonalId() { return personalId; }
    public void setPersonalId(long personalId) { this.personalId = personalId; }
    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }
    public double getHoras() { return horas; }
    public void setHoras(double horas) { this.horas = horas; }
}
