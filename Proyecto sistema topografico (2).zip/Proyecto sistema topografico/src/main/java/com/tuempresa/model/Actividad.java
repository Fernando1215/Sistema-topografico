package com.tuempresa.model;
public class Actividad {
    private long id;
    private long proyectoId;
    private String nombre;
    private String descripcion;
    private String fecha;
    private String estado;
    private Long responsableId;
    private String nombreProyecto;
    private String nombreResponsable;
    private double horasTrabajadas;
    private double costoPersonal;
    public Actividad() {}
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public long getProyectoId() { return proyectoId; }
    public void setProyectoId(long proyectoId) {this.proyectoId = proyectoId;}
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) {this.descripcion = descripcion;}
    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public Long getResponsableId() { return responsableId; }
    public void setResponsableId(Long responsableId) {this.responsableId = responsableId;}
    public String getNombreProyecto() { return nombreProyecto; }
    public void setNombreProyecto(String nombreProyecto) {this.nombreProyecto = nombreProyecto;}
    public String getNombreResponsable() {return nombreResponsable;}
    public void setNombreResponsable(String nombreResponsable) {this.nombreResponsable = nombreResponsable;}
    public double getHorasTrabajadas() { return horasTrabajadas; }
    public void setHorasTrabajadas(double horasTrabajadas) {this.horasTrabajadas = horasTrabajadas;}
    public double getCostoPersonal() {return costoPersonal;}
    public void setCostoPersonal(double costoPersonal) {this.costoPersonal = costoPersonal;}
}