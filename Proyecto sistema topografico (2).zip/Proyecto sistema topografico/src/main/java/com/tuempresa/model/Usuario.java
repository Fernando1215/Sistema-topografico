package com.tuempresa.model;

public class Usuario {

    private long id;
    private String correo;
    private String contrasena; // hash bcrypt
    private String nombre;
    private String rol;
    private boolean activo;

    public Usuario() {
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
}