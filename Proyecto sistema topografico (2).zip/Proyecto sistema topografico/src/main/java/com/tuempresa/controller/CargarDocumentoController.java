package com.tuempresa.controller;
import com.tuempresa.config.DBConnection;
import com.tuempresa.model.Documento;
import com.tuempresa.model.Proyecto;
import com.tuempresa.repository.DocumentoRepository;
import com.tuempresa.repository.ProyectoRepository;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;
import java.nio.file.Files;
public class CargarDocumentoController {
    @FXML private ComboBox<Proyecto> cbProyecto;
    @FXML private Label lblArchivoSeleccionado;
    @FXML private Button btnSeleccionarArchivo;
    @FXML private Button btnSubir;
    @FXML private Button btnVolverMenu;
    @FXML private ListView<Documento> listDocumentos;
    @FXML private Label lblMensaje;
    private final ProyectoRepository proyectoRepository = new ProyectoRepository();
    private final DocumentoRepository documentoRepository = new DocumentoRepository();
    private File archivoSeleccionado;
    @FXML
    private void initialize() {
        cbProyecto.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Proyecto p, boolean empty) {
                super.updateItem(p, empty);
                setText(empty || p == null ? null : p.getNombre());
            }
        });
        cbProyecto.setButtonCell(cbProyecto.getCellFactory().call(null));
        listDocumentos.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Documento d, boolean empty) {
                super.updateItem(d, empty);
                setText(empty || d == null ? null : d.getNombreArchivo() + "  (" + d.getFechaSubida() + ")");
            }
        });
        cbProyecto.valueProperty().addListener((obs, viejo, nuevo) -> {
            if (nuevo != null) cargarDocumentosDe(nuevo);
        });
        cargarProyectos();
    }
    private void cargarProyectos() {
        new Thread(() -> {
            try {
                var proyectos = proyectoRepository.obtenerTodos();
                Platform.runLater(() -> cbProyecto.getItems().setAll(proyectos));
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error al cargar proyectos: " + e.getMessage());
                });
            }
        }).start();
    }
    private void cargarDocumentosDe(Proyecto proyecto) {
        new Thread(() -> {
            try {
                var documentos = documentoRepository.obtenerPorProyecto(proyecto.getId());
                Platform.runLater(() -> listDocumentos.setItems(FXCollections.observableArrayList(documentos)));
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error al cargar documentos: " + e.getMessage());
                });
            }
        }).start();
    }
    @FXML
    private void onSeleccionarArchivoClick() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar documento");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Documentos", "*.pdf", "*.jpg", "*.jpeg", "*.png", "*.docx", "*.xlsx")
        );
        File archivo = fileChooser.showOpenDialog(btnSeleccionarArchivo.getScene().getWindow());
        if (archivo != null) {
            archivoSeleccionado = archivo;
            lblArchivoSeleccionado.setText(archivo.getName());
        }
    }
    @FXML
    private void onSubirClick() {
        Proyecto proyecto = cbProyecto.getValue();
        if (proyecto == null || archivoSeleccionado == null) {
            lblMensaje.setStyle("-fx-text-fill: red;");
            lblMensaje.setText("Selecciona un proyecto y un archivo.");
            return;
        }
        btnSubir.setDisable(true);
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Subiendo...");
        new Thread(() -> {
            try {
                byte[] contenido = Files.readAllBytes(archivoSeleccionado.toPath());
                String contentType = Files.probeContentType(archivoSeleccionado.toPath());
                if (contentType == null) contentType = "application/octet-stream";
                String nombreArchivo = archivoSeleccionado.getName();
                String pathEnBucket = proyecto.getId() + "/" + System.currentTimeMillis() + "_" + nombreArchivo;
                DBConnection.uploadFile("documentos", pathEnBucket, contenido, contentType);
                String urlPublica = DBConnection.getPublicUrl("documentos", pathEnBucket);
                Documento documento = new Documento();
                documento.setProyectoId(proyecto.getId());
                documento.setNombreArchivo(nombreArchivo);
                documento.setUrl(urlPublica);
                documentoRepository.registrarDocumento(documento);
                Platform.runLater(() -> {
                    btnSubir.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: green;");
                    lblMensaje.setText("Documento subido correctamente.");
                    archivoSeleccionado = null;
                    lblArchivoSeleccionado.setText("Ningún archivo seleccionado");
                    cargarDocumentosDe(proyecto);
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    btnSubir.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error: " + e.getMessage());
                });
            }
        }).start();
    }
    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}