package com.tuempresa.controller;

import com.tuempresa.model.Cliente;
import com.tuempresa.model.Pago;
import com.tuempresa.model.Proyecto;
import com.tuempresa.repository.ClienteRepository;
import com.tuempresa.repository.PagoRepository;
import com.tuempresa.repository.ProyectoRepository;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

public class RegistrarPagoController {

    @FXML private ComboBox<Cliente> cbCliente;
    @FXML private ComboBox<Proyecto> cbProyecto;
    @FXML private TextField txtMonto;
    @FXML private DatePicker dpFechaPago;
    @FXML private ComboBox<String> cbMetodoPago;
    @FXML private ComboBox<String> cbEstado;
    @FXML private TextArea txtConcepto;
    @FXML private Button btnGuardar;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;
    @FXML private Label lblSaldo;

    private final PagoRepository pagoRepository = new PagoRepository();
    private final ClienteRepository clienteRepository = new ClienteRepository();
    private final ProyectoRepository proyectoRepository = new ProyectoRepository();

    // Lista completa de proyectos y de clientes, para poder filtrar y cruzar sin volver a consultar
    private final List<Proyecto> todosLosProyectos = new ArrayList<>();
    private final List<Cliente> todosLosClientes = new ArrayList<>();

    // Pagos ya registrados: se usan para calcular cuánto lleva pagado cada proyecto
    private final List<Pago> todosLosPagos = new ArrayList<>();
    private boolean pagosCargados = false;

    // Control del monto que se escribe solo (saldo pendiente) para no pisar lo que digite el usuario
    private boolean escribiendoMonto = false;
    private boolean montoAutomatico = false;

    private static final Locale LOCALE_CO = Locale.forLanguageTag("es-CO");

    // Evita que los listeners se llamen entre sí en bucle cuando asignamos valores por código
    private boolean actualizandoAutomaticamente = false;

    @FXML
    private void initialize() {
        cbMetodoPago.getItems().addAll("efectivo", "transferencia", "tarjeta", "cheque");
        cbMetodoPago.setValue("efectivo");
        cbEstado.getItems().addAll("confirmado", "pendiente", "anulado");
        cbEstado.setValue("confirmado");
        dpFechaPago.setValue(java.time.LocalDate.now());

        cbCliente.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Cliente c, boolean empty) {
                super.updateItem(c, empty);
                setText(empty || c == null ? null : c.getNombre());
            }
        });
        cbCliente.setButtonCell(cbCliente.getCellFactory().call(null));

        cbProyecto.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Proyecto p, boolean empty) {
                super.updateItem(p, empty);
                setText(empty || p == null ? null : p.getNombre());
            }
        });
        cbProyecto.setButtonCell(cbProyecto.getCellFactory().call(null));

        // --- Asignación automática ---
        // 1) Al elegir cliente: se filtran sus proyectos y, si tiene uno solo, se selecciona.
        cbCliente.valueProperty().addListener((obs, viejo, nuevo) -> {
            if (actualizandoAutomaticamente) return;
            alCambiarCliente(nuevo);
        });
        // 2) Al elegir proyecto: se selecciona automáticamente su cliente.
        cbProyecto.valueProperty().addListener((obs, viejo, nuevo) -> {
            if (actualizandoAutomaticamente) return;
            alCambiarProyecto(nuevo);
        });

        // 3) Al quedar un proyecto elegido (a mano o automático): se calcula su saldo pendiente
        //    y se deja escrito en el monto, para solo verificar y guardar.
        cbProyecto.valueProperty().addListener((obs, viejo, nuevo) -> actualizarSaldo(nuevo));
        txtMonto.textProperty().addListener((obs, viejo, nuevo) -> {
            if (!escribiendoMonto) montoAutomatico = false;
        });

        cargarDatos();
    }

    private void alCambiarCliente(Cliente cliente) {
        actualizandoAutomaticamente = true;
        try {
            if (cliente == null) {
                // Sin cliente: se muestran todos los proyectos otra vez
                cbProyecto.getItems().setAll(todosLosProyectos);
                cbProyecto.setValue(null);
                return;
            }
            List<Proyecto> delCliente = new ArrayList<>();
            for (Proyecto p : todosLosProyectos) {
                if (p.getClienteId() == cliente.getId()) delCliente.add(p);
            }
            cbProyecto.getItems().setAll(delCliente);

            if (delCliente.size() == 1) {
                cbProyecto.setValue(delCliente.get(0));
                mostrarInfo("Proyecto asignado automáticamente: " + delCliente.get(0).getNombre());
            } else {
                cbProyecto.setValue(null);
                if (delCliente.isEmpty()) {
                    mostrarInfo("Este cliente no tiene proyectos; el pago se guardará sin proyecto.");
                } else {
                    mostrarInfo("Este cliente tiene " + delCliente.size() + " proyectos, elige uno.");
                }
            }
        } finally {
            actualizandoAutomaticamente = false;
        }
    }

    private void alCambiarProyecto(Proyecto proyecto) {
        if (proyecto == null) return;
        Cliente actual = cbCliente.getValue();
        if (actual != null && actual.getId() == proyecto.getClienteId()) return;

        for (Cliente c : todosLosClientes) {
            if (c.getId() == proyecto.getClienteId()) {
                actualizandoAutomaticamente = true;
                try {
                    cbCliente.setValue(c);
                    // Dejamos en el combo de proyectos solo los de ese cliente
                    List<Proyecto> delCliente = new ArrayList<>();
                    for (Proyecto p : todosLosProyectos) {
                        if (p.getClienteId() == c.getId()) delCliente.add(p);
                    }
                    cbProyecto.getItems().setAll(delCliente);
                    cbProyecto.setValue(proyecto);
                } finally {
                    actualizandoAutomaticamente = false;
                }
                mostrarInfo("Cliente asignado automáticamente: " + c.getNombre());
                return;
            }
        }
    }

    private double pagadoDe(long proyectoId) {
        double total = 0;
        for (Pago pg : todosLosPagos) {
            if (pg.getProyectoId() != null && pg.getProyectoId() == proyectoId
                    && "confirmado".equals(pg.getEstado())) {
                total += pg.getMonto();
            }
        }
        return total;
    }

    private String dinero(double valor) {
        return NumberFormat.getCurrencyInstance(LOCALE_CO).format(valor);
    }

    private void ponerMontoAutomatico(String texto) {
        escribiendoMonto = true;
        txtMonto.setText(texto);
        escribiendoMonto = false;
        montoAutomatico = !texto.isEmpty();
    }

    private void actualizarSaldo(Proyecto p) {
        if (p == null) {
            lblSaldo.setText("");
            if (montoAutomatico) ponerMontoAutomatico("");
            return;
        }
        if (!pagosCargados) {
            lblSaldo.setText("Calculando saldo...");
            return;
        }
        double valor = p.getValorTotal();
        if (valor <= 0) {
            lblSaldo.setText("Este proyecto no tiene valor total definido; no se puede calcular el saldo.");
            if (montoAutomatico) ponerMontoAutomatico("");
            return;
        }
        double pagado = pagadoDe(p.getId());
        double saldo = Math.max(valor - pagado, 0);
        String resumen = "Valor: " + dinero(valor) + "  |  Pagado: " + dinero(pagado)
                + "  |  Saldo pendiente: " + dinero(saldo);
        if (saldo > 0) {
            lblSaldo.setText(resumen);
            if (txtMonto.getText().trim().isEmpty() || montoAutomatico) {
                ponerMontoAutomatico(String.format(Locale.US, "%.2f", saldo));
            }
        } else {
            lblSaldo.setText(resumen + "  (proyecto pagado por completo)");
            if (montoAutomatico) ponerMontoAutomatico("");
        }
    }

    private void recargarPagos() {
        new Thread(() -> {
            try {
                var pagos = pagoRepository.obtenerTodos();
                Platform.runLater(() -> {
                    todosLosPagos.clear();
                    todosLosPagos.addAll(pagos);
                    pagosCargados = true;
                    actualizarSaldo(cbProyecto.getValue());
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("No se pudo actualizar el saldo: " + e.getMessage());
                });
            }
        }).start();
    }

    private void mostrarInfo(String texto) {
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText(texto);
    }

    private void cargarDatos() {
        new Thread(() -> {
            try {
                var clientes = clienteRepository.obtenerTodos();
                var proyectos = proyectoRepository.obtenerTodos();
                var pagos = pagoRepository.obtenerTodos();
                Platform.runLater(() -> {
                    todosLosClientes.clear();
                    todosLosClientes.addAll(clientes);
                    todosLosProyectos.clear();
                    todosLosProyectos.addAll(proyectos);
                    cbCliente.getItems().setAll(clientes);
                    cbProyecto.getItems().setAll(proyectos);
                    todosLosPagos.clear();
                    todosLosPagos.addAll(pagos);
                    pagosCargados = true;
                    actualizarSaldo(cbProyecto.getValue());
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error al cargar datos: " + e.getMessage());
                });
            }
        }).start();
    }

    @FXML
    private void onGuardarClick() {
        Cliente cliente = cbCliente.getValue();
        String montoTexto = txtMonto.getText().trim();

        if (cliente == null || montoTexto.isEmpty() || dpFechaPago.getValue() == null) {
            lblMensaje.setStyle("-fx-text-fill: red;");
            lblMensaje.setText("Cliente, monto y fecha son obligatorios.");
            return;
        }

        double monto;
        try {
            monto = Double.parseDouble(montoTexto.replace(",", "."));
        } catch (NumberFormatException e) {
            lblMensaje.setStyle("-fx-text-fill: red;");
            lblMensaje.setText("El monto debe ser un número válido.");
            return;
        }

        // Verificación: si el monto supera el saldo pendiente, se pide confirmación
        Proyecto proyectoSel = cbProyecto.getValue();
        if (proyectoSel != null && proyectoSel.getValorTotal() > 0 && pagosCargados
                && "confirmado".equals(cbEstado.getValue())) {
            double saldo = proyectoSel.getValorTotal() - pagadoDe(proyectoSel.getId());
            if (monto > saldo + 0.005) {
                Alert alerta = new Alert(Alert.AlertType.CONFIRMATION,
                        "El monto (" + dinero(monto) + ") supera el saldo pendiente ("
                                + dinero(Math.max(saldo, 0)) + ") del proyecto.\n¿Registrar el pago de todos modos?",
                        ButtonType.OK, ButtonType.CANCEL);
                alerta.setTitle("Confirmar pago");
                alerta.setHeaderText("El monto supera el saldo");
                Optional<ButtonType> respuesta = alerta.showAndWait();
                if (respuesta.isEmpty() || respuesta.get() != ButtonType.OK) return;
            }
        }

        Pago pago = new Pago();
        pago.setClienteId(cliente.getId());
        pago.setProyectoId(cbProyecto.getValue() != null ? cbProyecto.getValue().getId() : null);
        pago.setMonto(monto);
        pago.setFechaPago(dpFechaPago.getValue().toString());
        pago.setMetodoPago(cbMetodoPago.getValue());
        pago.setEstado(cbEstado.getValue());
        pago.setConcepto(txtConcepto.getText().trim());

        btnGuardar.setDisable(true);
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Guardando...");

        new Thread(() -> {
            try {
                pagoRepository.registrarPago(pago);
                Platform.runLater(() -> {
                    btnGuardar.setDisable(false);
                    limpiarFormulario();
                    lblMensaje.setStyle("-fx-text-fill: green;");
                    lblMensaje.setText("Pago registrado correctamente.");
                    pagosCargados = false;
                    recargarPagos();
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    btnGuardar.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error: " + e.getMessage());
                });
            }
        }).start();
    }

    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void limpiarFormulario() {
        actualizandoAutomaticamente = true;
        try {
            cbCliente.setValue(null);
            cbProyecto.getItems().setAll(todosLosProyectos);
            cbProyecto.setValue(null);
        } finally {
            actualizandoAutomaticamente = false;
        }
        txtMonto.clear();
        dpFechaPago.setValue(java.time.LocalDate.now());
        cbMetodoPago.setValue("efectivo");
        cbEstado.setValue("confirmado");
        txtConcepto.clear();
    }
}
