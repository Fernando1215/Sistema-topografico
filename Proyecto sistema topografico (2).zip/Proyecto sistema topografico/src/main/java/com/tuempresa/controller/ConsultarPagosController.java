package com.tuempresa.controller;
import com.tuempresa.model.Cliente;
import com.tuempresa.model.Pago;
import com.tuempresa.model.Proyecto;
import com.tuempresa.repository.ClienteRepository;
import com.tuempresa.repository.PagoRepository;
import com.tuempresa.repository.ProyectoRepository;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class ConsultarPagosController {
    @FXML private TableView<Pago> tablaPagos;
    @FXML private TableColumn<Pago, String> colCliente;
    @FXML private TableColumn<Pago, String> colProyecto;
    @FXML private TableColumn<Pago, Double> colMonto;
    @FXML private TableColumn<Pago, String> colFecha;
    @FXML private TableColumn<Pago, String> colMetodo;
    @FXML private TableColumn<Pago, String> colEstado;
    @FXML private ComboBox<String> cbFiltroEstado;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;
    private final PagoRepository pagoRepository = new PagoRepository();
    private final ClienteRepository clienteRepository = new ClienteRepository();
    private final ProyectoRepository proyectoRepository = new ProyectoRepository();
    private final ObservableList<Pago> datosCompletos = FXCollections.observableArrayList();
    private final ObservableList<Pago> datosFiltrados = FXCollections.observableArrayList();
    @FXML
    private void initialize() {
        colCliente.setCellValueFactory(new PropertyValueFactory<>("nombreCliente"));
        colProyecto.setCellValueFactory(new PropertyValueFactory<>("nombreProyecto"));
        colMonto.setCellValueFactory(new PropertyValueFactory<>("monto"));
        colFecha.setCellValueFactory(new PropertyValueFactory<>("fechaPago"));
        colMetodo.setCellValueFactory(new PropertyValueFactory<>("metodoPago"));
        colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));
        cbFiltroEstado.getItems().addAll("todos", "confirmado", "pendiente", "anulado");
        cbFiltroEstado.setValue("todos");
        cbFiltroEstado.valueProperty().addListener((obs, viejo, nuevo) -> aplicarFiltro());
        tablaPagos.setItems(datosFiltrados);
        cargarPagos();
    }
    private void cargarPagos() {
        lblMensaje.setText("Cargando...");
        new Thread(() -> {
            try {
                List<Pago> pagos = pagoRepository.obtenerTodos();
                List<Cliente> clientes = clienteRepository.obtenerTodos();
                List<Proyecto> proyectos = proyectoRepository.obtenerTodos();
                Map<Long, String> nombresClientes = new HashMap<>();
                for (Cliente c : clientes) nombresClientes.put(c.getId(), c.getNombre());
                Map<Long, String> nombresProyectos = new HashMap<>();
                for (Proyecto p : proyectos) nombresProyectos.put(p.getId(), p.getNombre());
                for (Pago pago : pagos) {
                    pago.setNombreCliente(nombresClientes.getOrDefault(pago.getClienteId(), "—"));
                    pago.setNombreProyecto(pago.getProyectoId() != null
                            ? nombresProyectos.getOrDefault(pago.getProyectoId(), "—")
                            : "—");
                }
                Platform.runLater(() -> {
                    datosCompletos.setAll(pagos);
                    aplicarFiltro();
                    lblMensaje.setText("");
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error al cargar pagos: " + e.getMessage());
                });
            }
        }).start();
    }
    private void aplicarFiltro() {
        String filtro = cbFiltroEstado.getValue();
        datosFiltrados.clear();
        if (filtro == null || filtro.equals("todos")) {
            datosFiltrados.addAll(datosCompletos);
        } else {
            for (Pago p : datosCompletos) {
                if (filtro.equals(p.getEstado())) {
                    datosFiltrados.add(p);
                }
            }
        }
    }
    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}