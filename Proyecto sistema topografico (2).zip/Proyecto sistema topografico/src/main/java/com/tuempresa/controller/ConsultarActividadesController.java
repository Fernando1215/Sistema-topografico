package com.tuempresa.controller;
import com.tuempresa.model.Actividad;
import com.tuempresa.model.Personal;
import com.tuempresa.model.Proyecto;
import com.tuempresa.repository.ActividadRepository;
import com.tuempresa.repository.PersonalRepository;
import com.tuempresa.repository.ProyectoRepository;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class ConsultarActividadesController {
    @FXML private TableView<Actividad> tablaActividades;
    @FXML private TableColumn<Actividad, String> colNombre;
    @FXML private TableColumn<Actividad, String> colProyecto;
    @FXML private TableColumn<Actividad, String> colResponsable;
    @FXML private TableColumn<Actividad, String> colEstado;
    @FXML private TableColumn<Actividad, String> colFecha;
    @FXML private ComboBox<String> cbFiltroEstado;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;
    private final ActividadRepository actividadRepository = new ActividadRepository();
    private final ProyectoRepository proyectoRepository = new ProyectoRepository();
    private final PersonalRepository personalRepository = new PersonalRepository();
    private final ObservableList<Actividad> datosCompletos = FXCollections.observableArrayList();
    private final ObservableList<Actividad> datosFiltrados = FXCollections.observableArrayList();
    @FXML
    private void initialize() {
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colProyecto.setCellValueFactory(new PropertyValueFactory<>("nombreProyecto"));
        colResponsable.setCellValueFactory(new PropertyValueFactory<>("nombreResponsable"));
        colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));
        colFecha.setCellValueFactory(new PropertyValueFactory<>("fecha"));
        cbFiltroEstado.getItems().addAll("todas", "pendiente", "en_proceso", "completada");
        cbFiltroEstado.setValue("todas");
        cbFiltroEstado.valueProperty().addListener((obs, viejo, nuevo) -> aplicarFiltro());
        tablaActividades.setItems(datosFiltrados);
        cargarActividades();
    }
    private void cargarActividades() {
        lblMensaje.setText("Cargando...");
        new Thread(() -> {
            try {
                List<Actividad> actividades = actividadRepository.obtenerTodas();
                List<Proyecto> proyectos = proyectoRepository.obtenerTodos();
                List<Personal> personal = personalRepository.obtenerTodos();
                Map<Long, String> nombresProyectos = new HashMap<>();
                for (Proyecto p : proyectos) nombresProyectos.put(p.getId(), p.getNombre());
                Map<Long, String> nombresPersonal = new HashMap<>();
                for (Personal p : personal) nombresPersonal.put(p.getId(), p.getNombre());
                for (Actividad a : actividades) {
                    a.setNombreProyecto(nombresProyectos.getOrDefault(a.getProyectoId(), "—"));
                    a.setNombreResponsable(a.getResponsableId() != null
                            ? nombresPersonal.getOrDefault(a.getResponsableId(), "—")
                            : "Sin asignar");
                }
                Platform.runLater(() -> {
                    datosCompletos.setAll(actividades);
                    aplicarFiltro();
                    lblMensaje.setText("");
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error al cargar actividades: " + e.getMessage());
                });
            }
        }).start();
    }
    private void aplicarFiltro() {
        String filtro = cbFiltroEstado.getValue();
        datosFiltrados.clear();
        if (filtro == null || filtro.equals("todas")) {
            datosFiltrados.addAll(datosCompletos);
        } else {
            for (Actividad a : datosCompletos) {
                if (filtro.equals(a.getEstado())) {
                    datosFiltrados.add(a);
                }
            }
        }
    }
    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}