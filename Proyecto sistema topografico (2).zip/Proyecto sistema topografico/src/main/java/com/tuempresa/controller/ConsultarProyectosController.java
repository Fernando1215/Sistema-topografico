package com.tuempresa.controller;
import com.tuempresa.model.Cliente;
import com.tuempresa.model.Proyecto;
import com.tuempresa.repository.ClienteRepository;
import com.tuempresa.repository.ProyectoRepository;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class ConsultarProyectosController {
    @FXML private TableView<Proyecto> tablaProyectos;
    @FXML private TableColumn<Proyecto, String> colNombre;
    @FXML private TableColumn<Proyecto, String> colCliente;
    @FXML private TableColumn<Proyecto, String> colEstado;
    @FXML private TableColumn<Proyecto, String> colFechaInicio;
    @FXML private TableColumn<Proyecto, String> colFechaFin;
    @FXML private ComboBox<String> cbFiltroEstado;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;
    private final ProyectoRepository proyectoRepository = new ProyectoRepository();
    private final ClienteRepository clienteRepository = new ClienteRepository();
    private final ObservableList<Proyecto> datosCompletos = FXCollections.observableArrayList();
    private final ObservableList<Proyecto> datosFiltrados = FXCollections.observableArrayList();
    @FXML
    private void initialize() {
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colCliente.setCellValueFactory(new PropertyValueFactory<>("nombreCliente"));
        colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));
        colFechaInicio.setCellValueFactory(new PropertyValueFactory<>("fechaInicio"));
        colFechaFin.setCellValueFactory(new PropertyValueFactory<>("fechaFin"));
        cbFiltroEstado.getItems().addAll("todos", "pendiente", "en_proceso", "finalizado");
        cbFiltroEstado.setValue("todos");
        cbFiltroEstado.valueProperty().addListener((obs, viejo, nuevo) -> aplicarFiltro());
        tablaProyectos.setItems(datosFiltrados);
        cargarProyectos();
    }
    private void cargarProyectos() {
        lblMensaje.setText("Cargando...");
        new Thread(() -> {
            try {
                List<Proyecto> proyectos = proyectoRepository.obtenerTodos();
                List<Cliente> clientes = clienteRepository.obtenerTodos();
                Map<Long, String> nombresClientes = new HashMap<>();
                for (Cliente c : clientes) {
                    nombresClientes.put(c.getId(), c.getNombre());
                }
                for (Proyecto p : proyectos) {
                    p.setNombreCliente(nombresClientes.getOrDefault(p.getClienteId(), "—"));
                }
                Platform.runLater(() -> {
                    datosCompletos.setAll(proyectos);
                    aplicarFiltro();
                    lblMensaje.setText("");
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error al cargar proyectos: " + e.getMessage());
                });
            }
        }).start();
    }
    private void aplicarFiltro() {
        String filtro = cbFiltroEstado.getValue();
        datosFiltrados.clear();
        if (filtro == null || filtro.equals("todos")) {
            datosFiltrados.addAll(datosCompletos);
        } else {
            for (Proyecto p : datosCompletos) {
                if (filtro.equals(p.getEstado())) {
                    datosFiltrados.add(p);
                }
            }
        }
    }
    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}