package com.tuempresa.controller;
import com.tuempresa.model.Personal;
import com.tuempresa.repository.PersonalRepository;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
public class RegistrarPersonalController {
    @FXML private TextField txtNombre;
    @FXML private TextField txtCargo;
    @FXML private TextField txtTelefono;
    @FXML private TextField txtCorreo;
    @FXML private TextField txtTarifaHora;
    @FXML private Button btnGuardar;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;
    private final PersonalRepository personalRepository = new PersonalRepository();
    @FXML
    private void onGuardarClick() {
        String nombre = txtNombre.getText().trim();
        if (nombre.isEmpty()) {
            lblMensaje.setStyle("-fx-text-fill: red;");
            lblMensaje.setText("El nombre es obligatorio.");
            return;
        }
        double tarifa = 0;
        String tarifaTexto = txtTarifaHora.getText().trim();
        if (!tarifaTexto.isEmpty()) {
            try {
                tarifa = Double.parseDouble(tarifaTexto.replace(",", "."));
            } catch (NumberFormatException e) {
                lblMensaje.setStyle("-fx-text-fill: red;");
                lblMensaje.setText("La tarifa por hora debe ser un número válido.");
                return;
            }
            if (tarifa < 0) {
                lblMensaje.setStyle("-fx-text-fill: red;");
                lblMensaje.setText("La tarifa por hora no puede ser negativa.");
                return;
            }
        }
        Personal p = new Personal();
        p.setTarifaHora(tarifa);
        p.setNombre(nombre);
        p.setCargo(txtCargo.getText().trim());
        p.setTelefono(txtTelefono.getText().trim());
        p.setCorreo(txtCorreo.getText().trim());
        btnGuardar.setDisable(true);
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Guardando...");
        new Thread(() -> {
            try {
                personalRepository.registrarPersonal(p);
                Platform.runLater(() -> {
                    btnGuardar.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: green;");
                    lblMensaje.setText("Personal registrado correctamente.");
                    txtNombre.clear(); txtCargo.clear(); txtTelefono.clear(); txtCorreo.clear(); txtTarifaHora.clear();
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    btnGuardar.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error: " + e.getMessage());
                });
            }
        }).start();
    }
    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}