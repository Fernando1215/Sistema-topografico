package com.tuempresa.controller;
import com.tuempresa.model.Cliente;
import com.tuempresa.repository.ClienteRepository;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
public class ConsultarClientesController {
    @FXML private TableView<Cliente> tablaClientes;
    @FXML private TableColumn<Cliente, String> colNombre;
    @FXML private TableColumn<Cliente, String> colDocumento;
    @FXML private TableColumn<Cliente, String> colTelefono;
    @FXML private TableColumn<Cliente, String> colCorreo;
    @FXML private TextField txtNombre;
    @FXML private TextField txtDocumento;
    @FXML private TextField txtTelefono;
    @FXML private TextField txtCorreo;
    @FXML private TextField txtDireccion;
    @FXML private ComboBox<String> cbTipoCliente;
    @FXML private Button btnGuardarCambios;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;
    private final ClienteRepository clienteRepository = new ClienteRepository();
    private final ObservableList<Cliente> datos = FXCollections.observableArrayList();
    private Cliente clienteSeleccionado;
    @FXML
    private void initialize() {
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colDocumento.setCellValueFactory(new PropertyValueFactory<>("documento"));
        colTelefono.setCellValueFactory(new PropertyValueFactory<>("telefono"));
        colCorreo.setCellValueFactory(new PropertyValueFactory<>("correo"));
        cbTipoCliente.getItems().addAll("natural", "empresa");
        tablaClientes.setItems(datos);
        tablaClientes.getSelectionModel().selectedItemProperty().addListener((obs, viejo, nuevo) -> {
            if (nuevo != null) cargarEnFormulario(nuevo);
        });
        cargarClientes();
    }
    private void cargarClientes() {
        new Thread(() -> {
            try {
                var lista = clienteRepository.obtenerTodos();
                Platform.runLater(() -> {
                    datos.setAll(lista);
                    lblMensaje.setText("");
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error al cargar clientes: " + e.getMessage());
                });
            }
        }).start();
    }
    private void cargarEnFormulario(Cliente c) {
        clienteSeleccionado = c;
        txtNombre.setText(c.getNombre());
        txtDocumento.setText(c.getDocumento());
        txtTelefono.setText(c.getTelefono());
        txtCorreo.setText(c.getCorreo());
        txtDireccion.setText(c.getDireccion());
        cbTipoCliente.setValue(c.getTipoCliente());
    }
    @FXML
    private void onGuardarCambiosClick() {
        if (clienteSeleccionado == null) {
            lblMensaje.setStyle("-fx-text-fill: red;");
            lblMensaje.setText("Selecciona un cliente de la tabla primero.");
            return;
        }
        clienteSeleccionado.setNombre(txtNombre.getText().trim());
        clienteSeleccionado.setDocumento(txtDocumento.getText().trim());
        clienteSeleccionado.setTelefono(txtTelefono.getText().trim());
        clienteSeleccionado.setCorreo(txtCorreo.getText().trim());
        clienteSeleccionado.setDireccion(txtDireccion.getText().trim());
        clienteSeleccionado.setTipoCliente(cbTipoCliente.getValue());
        btnGuardarCambios.setDisable(true);
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Guardando...");
        new Thread(() -> {
            try {
                clienteRepository.actualizarCliente(clienteSeleccionado);
                Platform.runLater(() -> {
                    btnGuardarCambios.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: green;");
                    lblMensaje.setText("Cliente actualizado correctamente.");
                    cargarClientes();
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    btnGuardarCambios.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error: " + e.getMessage());
                });
            }
        }).start();
    }
    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}