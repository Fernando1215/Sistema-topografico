package com.tuempresa.controller;

import com.tuempresa.model.Proyecto;
import com.tuempresa.model.Recurso;
import com.tuempresa.repository.ProyectoRepository;
import com.tuempresa.repository.RecursoRepository;
import com.tuempresa.util.Errores;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class ConsultarRecursosController {

    @FXML private ComboBox<Proyecto> cbFiltroProyecto;
    @FXML private Button btnVerTodos;
    @FXML private TableView<Recurso> tablaRecursos;
    @FXML private TableColumn<Recurso, String> colNombre;
    @FXML private TableColumn<Recurso, String> colTipo;
    @FXML private TableColumn<Recurso, String> colCodigo;
    @FXML private TableColumn<Recurso, String> colProyecto;
    @FXML private TableColumn<Recurso, String> colEstado;
    @FXML private TextField txtNombre;
    @FXML private ComboBox<String> cbTipo;
    @FXML private TextField txtCodigo;
    @FXML private TextField txtDescripcion;
    @FXML private ComboBox<Proyecto> cbProyecto;
    @FXML private ComboBox<String> cbEstado;
    @FXML private Button btnGuardarCambios;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;

    private final RecursoRepository recursoRepository = new RecursoRepository();
    private final ProyectoRepository proyectoRepository = new ProyectoRepository();
    private final ObservableList<Recurso> datos = FXCollections.observableArrayList();
    private final FilteredList<Recurso> filtrados = new FilteredList<>(datos, r -> true);
    private Recurso recursoSeleccionado;

    @FXML
    private void initialize() {
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colTipo.setCellValueFactory(new PropertyValueFactory<>("tipo"));
        colCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        colProyecto.setCellValueFactory(new PropertyValueFactory<>("nombreProyecto"));
        colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));

        cbTipo.getItems().addAll("equipo", "vehiculo", "herramienta", "software");
        cbEstado.getItems().addAll("disponible", "en_uso", "mantenimiento", "baja");

        StringConverter<Proyecto> conversor = new StringConverter<>() {
            @Override
            public String toString(Proyecto p) {
                return p == null ? "" : p.getNombre();
            }

            @Override
            public Proyecto fromString(String texto) {
                return null;
            }
        };
        cbProyecto.setConverter(conversor);
        cbFiltroProyecto.setConverter(conversor);

        tablaRecursos.setItems(filtrados);
        tablaRecursos.getSelectionModel().selectedItemProperty().addListener((obs, viejo, nuevo) -> {
            if (nuevo != null) cargarEnFormulario(nuevo);
        });

        cbFiltroProyecto.valueProperty().addListener((obs, viejo, nuevo) ->
                filtrados.setPredicate(r -> nuevo == null || r.getProyectoId() == nuevo.getId()));

        btnGuardarCambios.setDisable(true);
        cargarRecursos();
        cargarProyectos();
    }

    private void cargarRecursos() {
        new Thread(() -> {
            try {
                var lista = recursoRepository.obtenerTodos();
                Platform.runLater(() -> datos.setAll(lista));
            } catch (Exception e) {
                e.printStackTrace();
                String detalle = Errores.detalle(e);
                Platform.runLater(() -> mostrarError("Error al cargar recursos: " + detalle));
            }
        }).start();
    }

    private void cargarProyectos() {
        new Thread(() -> {
            try {
                var lista = proyectoRepository.obtenerTodos();
                Platform.runLater(() -> {
                    cbProyecto.getItems().setAll(lista);
                    cbFiltroProyecto.getItems().setAll(lista);
                });
            } catch (Exception e) {
                e.printStackTrace();
                String detalle = Errores.detalle(e);
                Platform.runLater(() -> mostrarError("Error al cargar proyectos: " + detalle));
            }
        }).start();
    }

    private void cargarEnFormulario(Recurso r) {
        recursoSeleccionado = r;
        txtNombre.setText(r.getNombre());
        cbTipo.setValue(r.getTipo());
        txtCodigo.setText(r.getCodigo());
        txtDescripcion.setText(r.getDescripcion());
        cbEstado.setValue(r.getEstado());
        cbProyecto.getItems().stream()
                .filter(p -> p.getId() == r.getProyectoId())
                .findFirst()
                .ifPresent(cbProyecto::setValue);
        btnGuardarCambios.setDisable(false);
    }

    private void limpiarFormulario() {
        recursoSeleccionado = null;
        txtNombre.clear();
        cbTipo.setValue(null);
        txtCodigo.clear();
        txtDescripcion.clear();
        cbEstado.setValue(null);
        cbProyecto.setValue(null);
        btnGuardarCambios.setDisable(true);
    }

    @FXML
    private void onVerTodosClick() {
        cbFiltroProyecto.setValue(null);
    }

    @FXML
    private void onGuardarCambiosClick() {
        if (recursoSeleccionado == null) {
            mostrarError("Selecciona un recurso de la tabla primero.");
            return;
        }
        String nombre = txtNombre.getText().trim();
        if (nombre.isEmpty() || cbTipo.getValue() == null || cbEstado.getValue() == null) {
            mostrarError("El nombre, el tipo y el estado son obligatorios.");
            return;
        }
        if (cbProyecto.getValue() == null) {
            mostrarError("El recurso debe pertenecer a un proyecto.");
            return;
        }

        recursoSeleccionado.setNombre(nombre);
        recursoSeleccionado.setTipo(cbTipo.getValue());
        recursoSeleccionado.setCodigo(txtCodigo.getText().trim());
        recursoSeleccionado.setDescripcion(txtDescripcion.getText().trim());
        recursoSeleccionado.setEstado(cbEstado.getValue());
        recursoSeleccionado.setProyectoId(cbProyecto.getValue().getId());

        Recurso r = recursoSeleccionado;
        btnGuardarCambios.setDisable(true);
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Guardando...");

        new Thread(() -> {
            try {
                recursoRepository.actualizarRecurso(r);
                Platform.runLater(() -> {
                    limpiarFormulario();
                    lblMensaje.setStyle("-fx-text-fill: green;");
                    lblMensaje.setText("Recurso actualizado correctamente.");
                    cargarRecursos();
                });
            } catch (Exception e) {
                e.printStackTrace();
                String detalle = Errores.detalle(e);
                Platform.runLater(() -> {
                    btnGuardarCambios.setDisable(false);
                    mostrarError(detalle);
                });
            }
        }).start();
    }

    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void mostrarError(String mensaje) {
        lblMensaje.setStyle("-fx-text-fill: red;");
        lblMensaje.setText(mensaje);
    }
}
