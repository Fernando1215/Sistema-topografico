package com.tuempresa.controller;
import com.tuempresa.model.Documento;
import com.tuempresa.model.Proyecto;
import com.tuempresa.repository.DocumentoRepository;
import com.tuempresa.repository.ProyectoRepository;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.awt.Desktop;
import java.net.URI;
public class ConsultarDocumentosController {
    @FXML private ComboBox<Proyecto> cbProyecto;
    @FXML private ListView<Documento> listDocumentos;
    @FXML private Button btnAbrir;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;
    private final ProyectoRepository proyectoRepository = new ProyectoRepository();
    private final DocumentoRepository documentoRepository = new DocumentoRepository();
    @FXML
    private void initialize() {
        cbProyecto.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Proyecto p, boolean empty) {
                super.updateItem(p, empty);
                setText(empty || p == null ? null : p.getNombre());
            }
        });
        cbProyecto.setButtonCell(cbProyecto.getCellFactory().call(null));
        listDocumentos.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Documento d, boolean empty) {
                super.updateItem(d, empty);
                setText(empty || d == null ? null : d.getNombreArchivo() + "  (" + d.getFechaSubida() + ")");
            }
        });
        cbProyecto.valueProperty().addListener((obs, viejo, nuevo) -> {
            if (nuevo != null) cargarDocumentosDe(nuevo);
        });
        cargarProyectos();
    }
    private void cargarProyectos() {
        new Thread(() -> {
            try {
                var proyectos = proyectoRepository.obtenerTodos();
                Platform.runLater(() -> cbProyecto.getItems().setAll(proyectos));
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error al cargar proyectos: " + e.getMessage());
                });
            }
        }).start();
    }
    private void cargarDocumentosDe(Proyecto proyecto) {
        lblMensaje.setText("Cargando...");
        new Thread(() -> {
            try {
                var documentos = documentoRepository.obtenerPorProyecto(proyecto.getId());
                Platform.runLater(() -> {
                    listDocumentos.setItems(FXCollections.observableArrayList(documentos));
                    lblMensaje.setText(documentos.isEmpty() ? "Este proyecto no tiene documentos." : "");
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error al cargar documentos: " + e.getMessage());
                });
            }
        }).start();
    }
    @FXML
    private void onAbrirClick() {
        Documento seleccionado = listDocumentos.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            lblMensaje.setStyle("-fx-text-fill: red;");
            lblMensaje.setText("Selecciona un documento de la lista primero.");
            return;
        }
        try {
            Desktop.getDesktop().browse(new URI(seleccionado.getUrl()));
        } catch (Exception e) {
            lblMensaje.setStyle("-fx-text-fill: red;");
            lblMensaje.setText("No se pudo abrir el documento: " + e.getMessage());
        }
    }
    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}