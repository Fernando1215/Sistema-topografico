package com.tuempresa.controller;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
public class MenuPrincipalController {
    @FXML private Label lblBienvenida;
    @FXML private Button btnRegistrarCliente;
    @FXML private Button btnConsultarClientes;
    @FXML private Button btnCrearProyecto;
    @FXML private Button btnConsultarProyectos;
    @FXML private Button btnRegistrarPersonal;
    @FXML private Button btnAsignarPersonal;
    @FXML private Button btnRegistrarActividad;
    @FXML private Button btnConsultarActividades;
    @FXML private Button btnRegistrarPago;
    @FXML private Button btnConsultarPagos;
    @FXML private Button btnPagarPersonal;
    @FXML private Button btnCargarDocumento;
    @FXML private Button btnConsultarDocumentos;
    @FXML private Button btnReporteProyectos;
    @FXML private Button btnDashboard;
    @FXML private Button btnRegistrarRecurso;
    @FXML private Button btnConsultarRecursos;
    @FXML private Button btnCerrarSesion;
    public void setNombreUsuario(String nombre) {
        lblBienvenida.setText("Bienvenido, " + nombre);
    }
    @FXML
    private void onRegistrarClienteClick() {
        cambiarPantalla("/com/tuempresa/registrar_cliente.fxml", "Registrar Cliente");
    }
    @FXML
    private void onConsultarClientesClick() {
        cambiarPantalla("/com/tuempresa/consultar_clientes.fxml", "Consultar Clientes");
    }
    @FXML
    private void onCrearProyectoClick() {
        cambiarPantalla("/com/tuempresa/registrar_proyecto.fxml", "Crear Proyecto");
    }
    @FXML
    private void onConsultarProyectosClick() {
        cambiarPantalla("/com/tuempresa/consultar_proyectos.fxml", "Consultar Proyectos");
    }
    @FXML
    private void onRegistrarPersonalClick() {
        cambiarPantalla("/com/tuempresa/registrar_personal.fxml", "Registrar Personal");
    }
    @FXML
    private void onAsignarPersonalClick() {
        cambiarPantalla("/com/tuempresa/asignar_personal.fxml", "Asignar Personal");
    }
    @FXML
    private void onRegistrarActividadClick() {
        cambiarPantalla("/com/tuempresa/registrar_actividad.fxml", "Registrar Actividad");
    }
    @FXML
    private void onConsultarActividadesClick() {
        cambiarPantalla("/com/tuempresa/consultar_actividades.fxml", "Consultar Actividades");
    }
    @FXML
    private void onRegistrarPagoClick() {
        cambiarPantalla("/com/tuempresa/registrar_pago.fxml", "Registrar Pago");
    }
    @FXML
    private void onConsultarPagosClick() {
        cambiarPantalla("/com/tuempresa/consultar_pagos.fxml", "Consultar Pagos");
    }
    @FXML
    private void onPagarPersonalClick() {
        cambiarPantalla("/com/tuempresa/pagar_personal.fxml", "Horas y pago de personal");
    }
    @FXML
    private void onCargarDocumentoClick() {
        cambiarPantalla("/com/tuempresa/cargar_documento.fxml", "Cargar Documentos");
    }
    @FXML
    private void onConsultarDocumentosClick() {
        cambiarPantalla("/com/tuempresa/consultar_documentos.fxml", "Consultar Documentos");
    }
    @FXML
    private void onReporteProyectosClick() {
        cambiarPantalla("/com/tuempresa/reporte_proyectos.fxml", "Reporte de Proyectos");
    }
    @FXML
    private void onDashboardClick() {
        cambiarPantalla("/com/tuempresa/dashboard.fxml", "Indicadores");
    }
    @FXML
    private void onRegistrarRecursoClick() {
        cambiarPantalla("/com/tuempresa/registrar_recurso.fxml", "Registrar Recurso");
    }
    @FXML
    private void onConsultarRecursosClick() {
        cambiarPantalla("/com/tuempresa/consultar_recursos.fxml", "Consultar y Asignar Recursos");
    }
    @FXML
    private void onCerrarSesionClick() {
        cambiarPantalla("/com/tuempresa/login.fxml", "Iniciar sesión");
    }
    private void cambiarPantalla(String fxmlPath, String titulo) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();
            Stage stage = (Stage) btnRegistrarCliente.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - " + titulo);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}