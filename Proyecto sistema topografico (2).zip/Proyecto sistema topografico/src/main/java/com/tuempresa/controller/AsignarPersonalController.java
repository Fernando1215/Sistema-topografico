package com.tuempresa.controller;
import com.tuempresa.model.Personal;
import com.tuempresa.model.Proyecto;
import com.tuempresa.repository.AsignacionRepository;
import com.tuempresa.repository.PersonalRepository;
import com.tuempresa.repository.ProyectoRepository;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
public class AsignarPersonalController {
    @FXML private ComboBox<Proyecto> cbProyecto;
    @FXML private ListView<Personal> listPersonal;
    @FXML private Button btnGuardar;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;
    private final ProyectoRepository proyectoRepository = new ProyectoRepository();
    private final PersonalRepository personalRepository = new PersonalRepository();
    private final AsignacionRepository asignacionRepository = new AsignacionRepository();
    @FXML
    private void initialize() {
        cbProyecto.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Proyecto p, boolean empty) {
                super.updateItem(p, empty);
                setText(empty || p == null ? null : p.getNombre());
            }
        });
        cbProyecto.setButtonCell(cbProyecto.getCellFactory().call(null));
        listPersonal.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Personal p, boolean empty) {
                super.updateItem(p, empty);
                setText(empty || p == null ? null : p.getNombre() + " (" + p.getCargo() + ")");
            }
        });
        listPersonal.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        cbProyecto.valueProperty().addListener((obs, viejo, nuevo) -> {
            if (nuevo != null) cargarAsignadosDe(nuevo);
        });
        cargarDatosIniciales();
    }
    private void cargarDatosIniciales() {
        new Thread(() -> {
            try {
                List<Proyecto> proyectos = proyectoRepository.obtenerTodos();
                List<Personal> personal = personalRepository.obtenerTodos();
                Platform.runLater(() -> {
                    cbProyecto.getItems().setAll(proyectos);
                    listPersonal.setItems(FXCollections.observableArrayList(personal));
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error al cargar datos: " + e.getMessage());
                });
            }
        }).start();
    }
    private void cargarAsignadosDe(Proyecto proyecto) {
        new Thread(() -> {
            try {
                Set<Long> asignados = asignacionRepository.obtenerAsignados(proyecto.getId());
                Platform.runLater(() -> {
                    listPersonal.getSelectionModel().clearSelection();
                    for (int i = 0; i < listPersonal.getItems().size(); i++) {
                        if (asignados.contains(listPersonal.getItems().get(i).getId())) {
                            listPersonal.getSelectionModel().select(i);
                        }
                    }
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error al cargar asignados: " + e.getMessage());
                });
            }
        }).start();
    }
    @FXML
    private void onGuardarClick() {
        Proyecto proyecto = cbProyecto.getValue();
        if (proyecto == null) {
            lblMensaje.setStyle("-fx-text-fill: red;");
            lblMensaje.setText("Selecciona un proyecto primero.");
            return;
        }
        Set<Long> seleccionados = listPersonal.getSelectionModel().getSelectedItems()
                .stream().map(Personal::getId).collect(Collectors.toCollection(HashSet::new));
        btnGuardar.setDisable(true);
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Guardando...");
        new Thread(() -> {
            try {
                asignacionRepository.guardarAsignaciones(proyecto.getId(), seleccionados);
                Platform.runLater(() -> {
                    btnGuardar.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: green;");
                    lblMensaje.setText("Asignaciones guardadas.");
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    btnGuardar.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error: " + e.getMessage());
                });
            }
        }).start();
    }
    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}