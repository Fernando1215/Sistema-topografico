package com.tuempresa.controller;

import com.tuempresa.model.Personal;
import com.tuempresa.model.Proyecto;
import com.tuempresa.model.RegistroHoras;
import com.tuempresa.repository.HorasRepository;
import com.tuempresa.repository.PersonalRepository;
import com.tuempresa.repository.ProyectoRepository;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

public class PagarPersonalController {

    private static final Locale LOCALE_CO = Locale.forLanguageTag("es-CO");

    // --- Registro de horas ---
    @FXML private ComboBox<Personal> cbPersonal;
    @FXML private TextField txtTarifa;
    @FXML private Button btnGuardarTarifa;
    @FXML private ComboBox<Proyecto> cbProyecto;
    @FXML private DatePicker dpFecha;
    @FXML private TextField txtHoras;
    @FXML private TextField txtDescripcion;
    @FXML private Button btnRegistrarHoras;

    // --- Pago pendiente ---
    @FXML private DatePicker dpHasta;
    @FXML private TableView<Liquidacion> tablaLiquidaciones;
    @FXML private TableColumn<Liquidacion, String> colTrabajador;
    @FXML private TableColumn<Liquidacion, String> colHoras;
    @FXML private TableColumn<Liquidacion, String> colTarifa;
    @FXML private TableColumn<Liquidacion, String> colMonto;
    @FXML private Label lblTotal;
    @FXML private Button btnPagarSeleccionado;
    @FXML private Button btnPagarTodos;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;

    private final PersonalRepository personalRepository = new PersonalRepository();
    private final ProyectoRepository proyectoRepository = new ProyectoRepository();
    private final HorasRepository horasRepository = new HorasRepository();

    /** Una fila de la tabla: lo que se le debe a un trabajador por sus horas pendientes. */
    public static class Liquidacion {
        private final long personalId;
        private final String nombre;
        private final double horas;
        private final double tarifaHora;
        private final double monto;
        private final List<Long> registroIds;

        public Liquidacion(long personalId, String nombre, double horas, double tarifaHora, List<Long> registroIds) {
            this.personalId = personalId;
            this.nombre = nombre;
            this.horas = horas;
            this.tarifaHora = tarifaHora;
            this.monto = Math.round(horas * tarifaHora * 100.0) / 100.0;
            this.registroIds = registroIds;
        }

        public long getPersonalId() { return personalId; }
        public String getNombre() { return nombre; }
        public double getHoras() { return horas; }
        public double getTarifaHora() { return tarifaHora; }
        public double getMonto() { return monto; }
        public List<Long> getRegistroIds() { return registroIds; }
        public String getHorasTexto() { return horasTxt(horas); }
        public String getTarifaTexto() { return tarifaHora > 0 ? dinero(tarifaHora) : "Sin tarifa"; }
        public String getMontoTexto() { return tarifaHora > 0 ? dinero(monto) : "—"; }
    }

    private static String dinero(double valor) {
        return NumberFormat.getCurrencyInstance(LOCALE_CO).format(valor);
    }

    private static String horasTxt(double horas) {
        return String.format(LOCALE_CO, "%.2f", horas);
    }

    @FXML
    private void initialize() {
        cbPersonal.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Personal p, boolean empty) {
                super.updateItem(p, empty);
                setText(empty || p == null ? null : p.getNombre());
            }
        });
        cbPersonal.setButtonCell(cbPersonal.getCellFactory().call(null));
        cbProyecto.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Proyecto p, boolean empty) {
                super.updateItem(p, empty);
                setText(empty || p == null ? null : p.getNombre());
            }
        });
        cbProyecto.setButtonCell(cbProyecto.getCellFactory().call(null));

        dpFecha.setValue(LocalDate.now());
        dpHasta.setValue(LocalDate.now());

        // Al elegir un trabajador se muestra su tarifa actual
        cbPersonal.valueProperty().addListener((obs, viejo, nuevo) -> {
            if (nuevo != null && nuevo.getTarifaHora() > 0) {
                txtTarifa.setText(String.format(Locale.US, "%.2f", nuevo.getTarifaHora()));
            } else {
                txtTarifa.clear();
            }
        });
        dpHasta.valueProperty().addListener((obs, viejo, nuevo) -> cargarPendientes());

        colTrabajador.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colHoras.setCellValueFactory(new PropertyValueFactory<>("horasTexto"));
        colTarifa.setCellValueFactory(new PropertyValueFactory<>("tarifaTexto"));
        colMonto.setCellValueFactory(new PropertyValueFactory<>("montoTexto"));

        cargarCombos();
        cargarPendientes();
    }

    private void cargarCombos() {
        Personal seleccionado = cbPersonal.getValue();
        Long seleccionadoId = seleccionado != null ? seleccionado.getId() : null;
        new Thread(() -> {
            try {
                List<Personal> personal = personalRepository.obtenerTodos();
                List<Proyecto> proyectos = proyectoRepository.obtenerTodos();
                Platform.runLater(() -> {
                    cbPersonal.getItems().setAll(personal);
                    if (seleccionadoId != null) {
                        for (Personal p : personal) {
                            if (p.getId() == seleccionadoId) {
                                cbPersonal.setValue(p);
                                break;
                            }
                        }
                    }
                    cbProyecto.getItems().setAll(proyectos);
                });
            } catch (Exception e) {
                Platform.runLater(() -> error("Error al cargar datos: " + e.getMessage()));
            }
        }).start();
    }

    private void cargarPendientes() {
        LocalDate hasta = dpHasta.getValue() != null ? dpHasta.getValue() : LocalDate.now();
        new Thread(() -> {
            try {
                List<Personal> personal = personalRepository.obtenerTodos();
                List<RegistroHoras> pendientes = horasRepository.obtenerPendientes(hasta.toString());

                Map<Long, Personal> porId = new HashMap<>();
                for (Personal p : personal) porId.put(p.getId(), p);

                Map<Long, List<RegistroHoras>> porTrabajador = new LinkedHashMap<>();
                for (RegistroHoras r : pendientes) {
                    porTrabajador.computeIfAbsent(r.getPersonalId(), k -> new ArrayList<>()).add(r);
                }

                List<Liquidacion> filas = new ArrayList<>();
                double total = 0;
                for (Map.Entry<Long, List<RegistroHoras>> e : porTrabajador.entrySet()) {
                    Personal p = porId.get(e.getKey());
                    double horas = 0;
                    List<Long> ids = new ArrayList<>();
                    for (RegistroHoras r : e.getValue()) {
                        horas += r.getHoras();
                        ids.add(r.getId());
                    }
                    String nombre = p != null ? p.getNombre() : "Personal #" + e.getKey();
                    double tarifa = p != null ? p.getTarifaHora() : 0;
                    Liquidacion fila = new Liquidacion(e.getKey(), nombre, horas, tarifa, ids);
                    filas.add(fila);
                    total += fila.getMonto();
                }
                final double totalFinal = total;
                Platform.runLater(() -> {
                    tablaLiquidaciones.getItems().setAll(filas);
                    lblTotal.setText("Total pendiente por pagar: " + dinero(totalFinal));
                });
            } catch (Exception e) {
                Platform.runLater(() -> error("Error al cargar horas pendientes: " + e.getMessage()));
            }
        }).start();
    }

    @FXML
    private void onGuardarTarifaClick() {
        Personal personal = cbPersonal.getValue();
        if (personal == null) {
            error("Selecciona un trabajador.");
            return;
        }
        double tarifa;
        try {
            tarifa = Double.parseDouble(txtTarifa.getText().trim().replace(",", "."));
        } catch (NumberFormatException e) {
            error("La tarifa por hora debe ser un número válido.");
            return;
        }
        if (tarifa <= 0) {
            error("La tarifa por hora debe ser mayor que cero.");
            return;
        }
        btnGuardarTarifa.setDisable(true);
        new Thread(() -> {
            try {
                personalRepository.actualizarTarifa(personal.getId(), tarifa);
                Platform.runLater(() -> {
                    btnGuardarTarifa.setDisable(false);
                    ok("Tarifa de " + personal.getNombre() + " actualizada.");
                    cargarCombos();
                    cargarPendientes();
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    btnGuardarTarifa.setDisable(false);
                    error("Error: " + e.getMessage());
                });
            }
        }).start();
    }

    @FXML
    private void onRegistrarHorasClick() {
        Personal personal = cbPersonal.getValue();
        if (personal == null || dpFecha.getValue() == null || txtHoras.getText().trim().isEmpty()) {
            error("Trabajador, fecha y horas son obligatorios.");
            return;
        }
        double horas;
        try {
            horas = Double.parseDouble(txtHoras.getText().trim().replace(",", "."));
        } catch (NumberFormatException e) {
            error("Las horas deben ser un número válido (ej: 8 o 7.5).");
            return;
        }
        if (horas <= 0 || horas > 24) {
            error("Las horas de un registro deben estar entre 0 y 24.");
            return;
        }
        Long proyectoId = cbProyecto.getValue() != null ? cbProyecto.getValue().getId() : null;
        String fecha = dpFecha.getValue().toString();
        String descripcion = txtDescripcion.getText().trim();

        btnRegistrarHoras.setDisable(true);
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Guardando...");
        new Thread(() -> {
            try {
                horasRepository.registrarHoras(personal.getId(), proyectoId, fecha, horas, descripcion);
                Platform.runLater(() -> {
                    btnRegistrarHoras.setDisable(false);
                    txtHoras.clear();
                    txtDescripcion.clear();
                    ok("Horas registradas para " + personal.getNombre() + ".");
                    cargarPendientes();
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    btnRegistrarHoras.setDisable(false);
                    error("Error: " + e.getMessage());
                });
            }
        }).start();
    }

    @FXML
    private void onPagarSeleccionadoClick() {
        Liquidacion seleccionada = tablaLiquidaciones.getSelectionModel().getSelectedItem();
        if (seleccionada == null) {
            error("Selecciona un trabajador de la tabla.");
            return;
        }
        confirmarYPagar(List.of(seleccionada));
    }

    @FXML
    private void onPagarTodosClick() {
        confirmarYPagar(new ArrayList<>(tablaLiquidaciones.getItems()));
    }

    private void confirmarYPagar(List<Liquidacion> filas) {
        List<Liquidacion> pagables = new ArrayList<>();
        List<String> sinTarifa = new ArrayList<>();
        for (Liquidacion l : filas) {
            if (l.getTarifaHora() > 0 && l.getHoras() > 0) {
                pagables.add(l);
            } else {
                sinTarifa.add(l.getNombre());
            }
        }
        if (pagables.isEmpty()) {
            error(sinTarifa.isEmpty()
                    ? "No hay horas pendientes por pagar."
                    : "Define la tarifa por hora de: " + String.join(", ", sinTarifa));
            return;
        }

        StringBuilder resumen = new StringBuilder();
        double total = 0;
        for (Liquidacion l : pagables) {
            resumen.append(l.getNombre()).append(": ")
                    .append(horasTxt(l.getHoras())).append(" h × ")
                    .append(dinero(l.getTarifaHora())).append(" = ")
                    .append(dinero(l.getMonto())).append("\n");
            total += l.getMonto();
        }
        resumen.append("\nTotal a pagar: ").append(dinero(total));
        if (!sinTarifa.isEmpty()) {
            resumen.append("\n\nNo se incluyen (sin tarifa): ").append(String.join(", ", sinTarifa));
        }

        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION, resumen.toString(), ButtonType.OK, ButtonType.CANCEL);
        alerta.setTitle("Confirmar pago de personal");
        alerta.setHeaderText("Verifica los valores antes de pagar");
        Optional<ButtonType> respuesta = alerta.showAndWait();
        if (respuesta.isEmpty() || respuesta.get() != ButtonType.OK) {
            return;
        }

        btnPagarSeleccionado.setDisable(true);
        btnPagarTodos.setDisable(true);
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Registrando pagos...");
        String fechaPago = LocalDate.now().toString();
        new Thread(() -> {
            int pagados = 0;
            List<String> errores = new ArrayList<>();
            for (Liquidacion l : pagables) {
                try {
                    horasRepository.pagarHoras(l.getPersonalId(), l.getRegistroIds(), fechaPago);
                    pagados++;
                } catch (Exception e) {
                    errores.add(l.getNombre() + ": " + e.getMessage());
                }
            }
            final int totalPagados = pagados;
            Platform.runLater(() -> {
                btnPagarSeleccionado.setDisable(false);
                btnPagarTodos.setDisable(false);
                if (errores.isEmpty()) {
                    ok("Pago registrado para " + totalPagados + " trabajador(es).");
                } else {
                    error("Pagados: " + totalPagados + ". Con error → " + String.join(" | ", errores));
                }
                cargarPendientes();
            });
        }).start();
    }

    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void ok(String texto) {
        lblMensaje.setStyle("-fx-text-fill: green;");
        lblMensaje.setText(texto);
    }

    private void error(String texto) {
        lblMensaje.setStyle("-fx-text-fill: red;");
        lblMensaje.setText(texto);
    }
}
