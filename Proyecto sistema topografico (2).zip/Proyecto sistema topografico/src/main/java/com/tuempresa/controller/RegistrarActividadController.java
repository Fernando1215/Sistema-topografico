package com.tuempresa.controller;
import com.tuempresa.model.Actividad;
import com.tuempresa.model.Personal;
import com.tuempresa.model.Proyecto;
import com.tuempresa.repository.ActividadRepository;
import com.tuempresa.repository.PersonalRepository;
import com.tuempresa.repository.ProyectoRepository;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
public class RegistrarActividadController {
    @FXML private ComboBox<Proyecto> cbProyecto;
    @FXML private TextField txtNombre;
    @FXML private TextArea txtDescripcion;
    @FXML private DatePicker dpFecha;
    @FXML private ComboBox<String> cbEstado;
    @FXML private ComboBox<Personal> cbResponsable;
    @FXML private Button btnGuardar;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;
    private final ActividadRepository actividadRepository = new ActividadRepository();
    private final ProyectoRepository proyectoRepository = new ProyectoRepository();
    private final PersonalRepository personalRepository = new PersonalRepository();
    @FXML
    private void initialize() {
        cbEstado.getItems().addAll("pendiente", "en_proceso", "completada");
        cbEstado.setValue("pendiente");
        cbProyecto.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Proyecto p, boolean empty) {
                super.updateItem(p, empty);
                setText(empty || p == null ? null : p.getNombre());
            }
        });
        cbProyecto.setButtonCell(cbProyecto.getCellFactory().call(null));
        cbResponsable.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Personal p, boolean empty) {
                super.updateItem(p, empty);
                setText(empty || p == null ? null : p.getNombre());
            }
        });
        cbResponsable.setButtonCell(cbResponsable.getCellFactory().call(null));

        cargarDatos();
    }
    private void cargarDatos() {
        new Thread(() -> {
            try {
                var proyectos = proyectoRepository.obtenerTodos();
                var personal = personalRepository.obtenerTodos();
                Platform.runLater(() -> {
                    cbProyecto.getItems().setAll(proyectos);
                    cbResponsable.getItems().setAll(personal);
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error al cargar datos: " + e.getMessage());
                });
            }
        }).start();
    }
    @FXML
    private void onGuardarClick() {
        Proyecto proyecto = cbProyecto.getValue();
        String nombre = txtNombre.getText().trim();
        if (proyecto == null || nombre.isEmpty()) {
            lblMensaje.setStyle("-fx-text-fill: red;");
            lblMensaje.setText("Proyecto y nombre de la actividad son obligatorios.");
            return;
        }
        Actividad actividad = new Actividad();
        actividad.setProyectoId(proyecto.getId());
        actividad.setNombre(nombre);
        actividad.setDescripcion(txtDescripcion.getText().trim());
        actividad.setEstado(cbEstado.getValue());
        actividad.setFecha(dpFecha.getValue() != null ? dpFecha.getValue().toString() : null);
        actividad.setResponsableId(cbResponsable.getValue() != null ? cbResponsable.getValue().getId() : null);
        btnGuardar.setDisable(true);
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Guardando...");
        new Thread(() -> {
            try {
                actividadRepository.registrarActividad(actividad);
                Platform.runLater(() -> {
                    btnGuardar.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: green;");
                    lblMensaje.setText("Actividad registrada correctamente.");
                    limpiarFormulario();
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    btnGuardar.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error: " + e.getMessage());
                });
            }
        }).start();
    }
    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void limpiarFormulario() {
        txtNombre.clear();
        txtDescripcion.clear();
        dpFecha.setValue(null);
        cbEstado.setValue("pendiente");
        cbResponsable.setValue(null);
    }
}