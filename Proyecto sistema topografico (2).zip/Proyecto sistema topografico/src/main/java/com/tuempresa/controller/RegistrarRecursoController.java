package com.tuempresa.controller;

import com.tuempresa.model.Proyecto;
import com.tuempresa.model.Recurso;
import com.tuempresa.repository.ProyectoRepository;
import com.tuempresa.repository.RecursoRepository;
import com.tuempresa.util.Errores;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class RegistrarRecursoController {

    @FXML private ComboBox<Proyecto> cbProyecto;
    @FXML private TextField txtNombre;
    @FXML private ComboBox<String> cbTipo;
    @FXML private TextField txtCodigo;
    @FXML private TextField txtDescripcion;
    @FXML private DatePicker dpFechaAdquisicion;
    @FXML private Button btnGuardar;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;

    private final RecursoRepository recursoRepository = new RecursoRepository();
    private final ProyectoRepository proyectoRepository = new ProyectoRepository();

    @FXML
    private void initialize() {
        cbTipo.getItems().addAll("equipo", "vehiculo", "herramienta", "software");

        cbProyecto.setConverter(new StringConverter<>() {
            @Override
            public String toString(Proyecto p) {
                return p == null ? "" : p.getNombre();
            }

            @Override
            public Proyecto fromString(String texto) {
                return null;
            }
        });

        cargarProyectos();
    }

    private void cargarProyectos() {
        new Thread(() -> {
            try {
                var lista = proyectoRepository.obtenerTodos();
                Platform.runLater(() -> cbProyecto.getItems().setAll(lista));
            } catch (Exception e) {
                e.printStackTrace();
                String detalle = Errores.detalle(e);
                Platform.runLater(() -> mostrarError("Error al cargar proyectos: " + detalle));
            }
        }).start();
    }

    @FXML
    private void onGuardarClick() {
        Proyecto proyecto = cbProyecto.getValue();
        String nombre = txtNombre.getText().trim();
        String tipo = cbTipo.getValue();

        if (proyecto == null) {
            mostrarError("Selecciona el proyecto al que pertenece el recurso.");
            return;
        }
        if (nombre.isEmpty()) {
            mostrarError("El nombre es obligatorio.");
            return;
        }
        if (tipo == null) {
            mostrarError("Selecciona el tipo de recurso.");
            return;
        }

        Recurso r = new Recurso();
        r.setProyectoId(proyecto.getId());
        r.setNombre(nombre);
        r.setTipo(tipo);
        r.setCodigo(txtCodigo.getText().trim());
        r.setDescripcion(txtDescripcion.getText().trim());
        if (dpFechaAdquisicion.getValue() != null) {
            r.setFechaAdquisicion(dpFechaAdquisicion.getValue().toString());
        }

        btnGuardar.setDisable(true);
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Guardando...");

        new Thread(() -> {
            try {
                recursoRepository.registrarRecurso(r);
                Platform.runLater(() -> {
                    btnGuardar.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: green;");
                    lblMensaje.setText("Recurso registrado en el proyecto " + proyecto.getNombre() + ".");
                    txtNombre.clear();
                    cbTipo.setValue(null);
                    txtCodigo.clear();
                    txtDescripcion.clear();
                    dpFechaAdquisicion.setValue(null);
                });
            } catch (Exception e) {
                e.printStackTrace();
                String detalle = Errores.detalle(e);
                Platform.runLater(() -> {
                    btnGuardar.setDisable(false);
                    mostrarError(detalle);
                });
            }
        }).start();
    }

    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void mostrarError(String mensaje) {
        lblMensaje.setStyle("-fx-text-fill: red;");
        lblMensaje.setText(mensaje);
    }
}
