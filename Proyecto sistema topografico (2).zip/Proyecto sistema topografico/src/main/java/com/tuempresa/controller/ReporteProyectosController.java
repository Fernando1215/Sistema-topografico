package com.tuempresa.controller;
import com.tuempresa.model.Cliente;
import com.tuempresa.model.Proyecto;
import com.tuempresa.repository.ClienteRepository;
import com.tuempresa.repository.ProyectoRepository;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import java.awt.Desktop;
import java.io.File;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class ReporteProyectosController {
    @FXML private ComboBox<String> cbFiltroEstado;
    @FXML private Button btnGenerar;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;
    private final ProyectoRepository proyectoRepository = new ProyectoRepository();
    private final ClienteRepository clienteRepository = new ClienteRepository();
    @FXML
    private void initialize() {
        cbFiltroEstado.getItems().addAll("todos", "pendiente", "en_proceso", "finalizado");
        cbFiltroEstado.setValue("todos");
    }
    @FXML
    private void onGenerarClick() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Guardar reporte de proyectos");
        fileChooser.setInitialFileName("reporte_proyectos.pdf");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF", "*.pdf"));
        File destino = fileChooser.showSaveDialog(btnGenerar.getScene().getWindow());
        if (destino == null) return;
        btnGenerar.setDisable(true);
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Generando reporte...");
        new Thread(() -> {
            try {
                List<Proyecto> proyectos = proyectoRepository.obtenerTodos();
                List<Cliente> clientes = clienteRepository.obtenerTodos();
                Map<Long, String> nombresClientes = new HashMap<>();
                for (Cliente c : clientes) nombresClientes.put(c.getId(), c.getNombre());
                String filtro = cbFiltroEstado.getValue();
                List<Proyecto> filtrados = proyectos.stream()
                        .filter(p -> filtro.equals("todos") || filtro.equals(p.getEstado()))
                        .toList();
                generarPdf(destino, filtrados, nombresClientes);
                Platform.runLater(() -> {
                    btnGenerar.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: green;");
                    lblMensaje.setText("Reporte generado: " + destino.getName());
                });
                Desktop.getDesktop().open(destino);
            } catch (Exception e) {
                Platform.runLater(() -> {
                    btnGenerar.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error al generar el reporte: " + e.getMessage());
                });
            }
        }).start();
    }
    private void generarPdf(File destino, List<Proyecto> proyectos, Map<Long, String> nombresClientes) throws Exception {
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);
            PDPageContentStream cs = new PDPageContentStream(document, page);
            float margenIzq = 50;
            float y = 780;
            float alturaLinea = 18;
            PDType1Font fuenteTitulo = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
            PDType1Font fuenteTexto = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
            cs.beginText();
            cs.setFont(fuenteTitulo, 16);
            cs.newLineAtOffset(margenIzq, y);
            cs.showText("Reporte de Proyectos");
            cs.endText();
            y -= alturaLinea;
            cs.beginText();
            cs.setFont(fuenteTexto, 10);
            cs.newLineAtOffset(margenIzq, y);
            cs.showText("Generado el " + LocalDate.now());
            cs.endText();
            y -= alturaLinea * 2;
            cs.setFont(fuenteTitulo, 10);
            cs.beginText();
            cs.newLineAtOffset(margenIzq, y);
            cs.showText(String.format("%-30s %-20s %-15s %-12s", "Proyecto", "Cliente", "Estado", "Inicio"));
            cs.endText();
            y -= alturaLinea;
            cs.setFont(fuenteTexto, 10);
            for (Proyecto p : proyectos) {
                if (y < 60) {
                    cs.close();
                    page = new PDPage(PDRectangle.A4);
                    document.addPage(page);
                    cs = new PDPageContentStream(document, page);
                    y = 780;
                }
                String nombreCliente = nombresClientes.getOrDefault(p.getClienteId(), "—");
                String fila = String.format("%-30s %-20s %-15s %-12s",
                        recortar(p.getNombre(), 28),
                        recortar(nombreCliente, 18),
                        p.getEstado(),
                        p.getFechaInicio() != null && !p.getFechaInicio().isEmpty() ? p.getFechaInicio() : "—");
                cs.beginText();
                cs.newLineAtOffset(margenIzq, y);
                cs.showText(fila);
                cs.endText();
                y -= alturaLinea;
            }
            cs.close();
            document.save(destino);
        }
    }
    private String recortar(String texto, int maxLen) {
        if (texto == null) return "";
        return texto.length() <= maxLen ? texto : texto.substring(0, maxLen - 1) + "…";
    }
    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}