package com.tuempresa.controller;
import com.tuempresa.model.Cliente;
import com.tuempresa.model.Proyecto;
import com.tuempresa.repository.ClienteRepository;
import com.tuempresa.repository.ProyectoRepository;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
public class RegistrarProyectoController {
    @FXML private TextField txtNombre;
    @FXML private TextArea txtDescripcion;
    @FXML private ComboBox<Cliente> cbCliente;
    @FXML private TextField txtValorTotal;
    @FXML private ComboBox<String> cbEstado;
    @FXML private DatePicker dpFechaInicio;
    @FXML private DatePicker dpFechaFin;
    @FXML private Button btnGuardar;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;
    private final ProyectoRepository proyectoRepository = new ProyectoRepository();
    private final ClienteRepository clienteRepository = new ClienteRepository();
    @FXML
    private void initialize() {
        cbEstado.getItems().addAll("pendiente", "en_proceso", "finalizado");
        cbEstado.setValue("pendiente");
        cbCliente.setCellFactory(lv -> new ListCell<>() {
            @Override
            protected void updateItem(Cliente c, boolean empty) {
                super.updateItem(c, empty);
                setText(empty || c == null ? null : c.getNombre());
            }
        });
        cbCliente.setButtonCell(cbCliente.getCellFactory().call(null));

        cargarClientes();
    }
    private void cargarClientes() {
        new Thread(() -> {
            try {
                var lista = clienteRepository.obtenerTodos();
                Platform.runLater(() -> cbCliente.getItems().setAll(lista));
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("No se pudieron cargar los clientes: " + e.getMessage());
                });
            }
        }).start();
    }
    @FXML
    private void onGuardarClick() {
        String nombre = txtNombre.getText().trim();
        Cliente cliente = cbCliente.getValue();
        if (nombre.isEmpty() || cliente == null) {
            lblMensaje.setStyle("-fx-text-fill: red;");
            lblMensaje.setText("Nombre del proyecto y cliente son obligatorios.");
            return;
        }
        double valorTotal = 0;
        String valorTexto = txtValorTotal.getText().trim();
        if (!valorTexto.isEmpty()) {
            try {
                valorTotal = Double.parseDouble(valorTexto.replace(",", "."));
            } catch (NumberFormatException e) {
                lblMensaje.setStyle("-fx-text-fill: red;");
                lblMensaje.setText("El valor total debe ser un número válido.");
                return;
            }
            if (valorTotal < 0) {
                lblMensaje.setStyle("-fx-text-fill: red;");
                lblMensaje.setText("El valor total no puede ser negativo.");
                return;
            }
        }
        Proyecto proyecto = new Proyecto();
        proyecto.setValorTotal(valorTotal);
        proyecto.setNombre(nombre);
        proyecto.setDescripcion(txtDescripcion.getText().trim());
        proyecto.setClienteId(cliente.getId());
        proyecto.setEstado(cbEstado.getValue());
        proyecto.setFechaInicio(dpFechaInicio.getValue() != null ? dpFechaInicio.getValue().toString() : null);
        proyecto.setFechaFin(dpFechaFin.getValue() != null ? dpFechaFin.getValue().toString() : null);
        btnGuardar.setDisable(true);
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Guardando...");
        new Thread(() -> {
            try {
                proyectoRepository.registrarProyecto(proyecto);
                Platform.runLater(() -> {
                    btnGuardar.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: green;");
                    lblMensaje.setText("Proyecto registrado correctamente.");
                    limpiarFormulario();
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    btnGuardar.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error: " + e.getMessage());
                });
            }
        }).start();
    }
    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void limpiarFormulario() {
        txtNombre.clear();
        txtDescripcion.clear();
        txtValorTotal.clear();
        cbCliente.setValue(null);
        cbEstado.setValue("pendiente");
        dpFechaInicio.setValue(null);
        dpFechaFin.setValue(null);
    }
}