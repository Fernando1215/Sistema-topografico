package com.tuempresa.controller;
import com.tuempresa.model.Cliente;
import com.tuempresa.repository.ClienteRepository;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
public class RegistrarClienteController {
    @FXML private TextField txtNombre;
    @FXML private TextField txtDocumento;
    @FXML private TextField txtTelefono;
    @FXML private TextField txtCorreo;
    @FXML private TextField txtDireccion;
    @FXML private ComboBox<String> cbTipoCliente;
    @FXML private Button btnGuardar;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;
    private final ClienteRepository clienteRepository = new ClienteRepository();
    @FXML
    private void initialize() {
        cbTipoCliente.getItems().addAll("natural", "empresa");
        cbTipoCliente.setValue("natural");
    }
    @FXML
    private void onGuardarClick() {
        String nombre = txtNombre.getText().trim();
        String documento = txtDocumento.getText().trim();
        if (nombre.isEmpty() || documento.isEmpty()) {
            lblMensaje.setStyle("-fx-text-fill: red;");
            lblMensaje.setText("Nombre y documento son obligatorios.");
            return;
        }
        Cliente cliente = new Cliente();
        cliente.setNombre(nombre);
        cliente.setDocumento(documento);
        cliente.setTelefono(txtTelefono.getText().trim());
        cliente.setCorreo(txtCorreo.getText().trim());
        cliente.setDireccion(txtDireccion.getText().trim());
        cliente.setTipoCliente(cbTipoCliente.getValue());
        btnGuardar.setDisable(true);
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Guardando...");
        new Thread(() -> {
            try {
                clienteRepository.registrarCliente(cliente);
                Platform.runLater(() -> {
                    btnGuardar.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: green;");
                    lblMensaje.setText("Cliente registrado correctamente.");
                    limpiarFormulario();
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    btnGuardar.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error: " + e.getMessage());
                });
            }
        }).start();
    }
    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void limpiarFormulario() {
        txtNombre.clear();
        txtDocumento.clear();
        txtTelefono.clear();
        txtCorreo.clear();
        txtDireccion.clear();
        cbTipoCliente.setValue("natural");
    }
}