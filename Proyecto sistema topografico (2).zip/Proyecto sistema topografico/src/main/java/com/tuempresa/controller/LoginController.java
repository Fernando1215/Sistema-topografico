package com.tuempresa.controller;
import com.tuempresa.model.Usuario;
import com.tuempresa.repository.UsuarioRepository;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
public class LoginController {
    @FXML private TextField txtCorreo;
    @FXML private PasswordField txtContrasena;
    @FXML private Button btnLogin;
    @FXML private Label lblMensaje;
    private final UsuarioRepository usuarioRepository = new UsuarioRepository();
    @FXML
    private void onLoginClick() {
        String correo = txtCorreo.getText().trim();
        String contrasena = txtContrasena.getText();

        if (correo.isEmpty() || contrasena.isEmpty()) {
            lblMensaje.setStyle("-fx-text-fill: red;");
            lblMensaje.setText("Debes ingresar correo y contraseña.");
            return;
        }

        if (!validarCorreo(correo)) {
            lblMensaje.setStyle("-fx-text-fill: red;");
            lblMensaje.setText("El formato del correo no es válido.");
            return;
        }

        btnLogin.setDisable(true);
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Verificando...");

        new Thread(() -> {
            try {
                Usuario usuario = usuarioRepository.validarLogin(
                        correo, contrasena
                );

                Platform.runLater(() -> {
                    btnLogin.setDisable(false);

                    if (usuario != null) {
                        lblMensaje.setStyle("-fx-text-fill: green;");
                        lblMensaje.setText(
                                "Bienvenido, " + usuario.getNombre()
                        );
                        irAMenuPrincipal(usuario.getNombre());
                    } else {
                        lblMensaje.setStyle("-fx-text-fill: red;");
                        lblMensaje.setText(
                                "Correo o contraseña incorrectos."
                        );
                    }
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    btnLogin.setDisable(false);
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error: " + e.getMessage());
                });
            }
        }).start();
    }
    private void irAMenuPrincipal(String nombreUsuario) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();

            MenuPrincipalController controller = loader.getController();
            controller.setNombreUsuario(nombreUsuario);

            Stage stage = (Stage) btnLogin.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
            lblMensaje.setStyle("-fx-text-fill: red;");
            lblMensaje.setText("No se pudo abrir el menú: " + e.getMessage());
        }
    }
    private boolean validarCorreo(String correo) {
        String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        return correo.matches(regex);
    }
}