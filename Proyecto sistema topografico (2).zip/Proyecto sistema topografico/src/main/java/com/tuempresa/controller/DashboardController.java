package com.tuempresa.controller;
import com.tuempresa.model.*;
import com.tuempresa.repository.*;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import java.util.List;
import java.util.Locale;
public class DashboardController {
    @FXML private Label lblTotalClientes;
    @FXML private Label lblTotalPersonalActivo;
    @FXML private Label lblProyectosTotal;
    @FXML private Label lblProyectosPendientes;
    @FXML private Label lblProyectosEnProceso;
    @FXML private Label lblProyectosFinalizados;
    @FXML private Label lblActividadesPendientes;
    @FXML private Label lblActividadesEnProceso;
    @FXML private Label lblActividadesCompletadas;
    @FXML private Label lblPagosConfirmados;
    @FXML private Label lblPagosPendientes;
    @FXML private Label lblMontoConfirmado;
    @FXML private Button btnActualizar;
    @FXML private Button btnVolverMenu;
    @FXML private Label lblMensaje;
    private final ClienteRepository clienteRepository = new ClienteRepository();
    private final ProyectoRepository proyectoRepository = new ProyectoRepository();
    private final PersonalRepository personalRepository = new PersonalRepository();
    private final ActividadRepository actividadRepository = new ActividadRepository();
    private final PagoRepository pagoRepository = new PagoRepository();
    @FXML
    private void initialize() {
        cargarIndicadores();
    }
    @FXML
    private void onActualizarClick() {
        cargarIndicadores();
    }
    private void cargarIndicadores() {
        lblMensaje.setStyle("-fx-text-fill: gray;");
        lblMensaje.setText("Cargando indicadores...");
        new Thread(() -> {
            try {
                List<Cliente> clientes = clienteRepository.obtenerTodos();
                List<Proyecto> proyectos = proyectoRepository.obtenerTodos();
                List<Personal> personal = personalRepository.obtenerTodos();
                List<Actividad> actividades = actividadRepository.obtenerTodas();
                List<Pago> pagos = pagoRepository.obtenerTodos();
                long proyPendientes = proyectos.stream().filter(p -> "pendiente".equals(p.getEstado())).count();
                long proyEnProceso = proyectos.stream().filter(p -> "en_proceso".equals(p.getEstado())).count();
                long proyFinalizados = proyectos.stream().filter(p -> "finalizado".equals(p.getEstado())).count();
                long personalActivo = personal.stream().filter(Personal::isActivo).count();
                long actPendientes = actividades.stream().filter(a -> "pendiente".equals(a.getEstado())).count();
                long actEnProceso = actividades.stream().filter(a -> "en_proceso".equals(a.getEstado())).count();
                long actCompletadas = actividades.stream().filter(a -> "completada".equals(a.getEstado())).count();
                long pagosConfirmados = pagos.stream().filter(p -> "confirmado".equals(p.getEstado())).count();
                long pagosPendientes = pagos.stream().filter(p -> "pendiente".equals(p.getEstado())).count();
                double montoConfirmado = pagos.stream()
                        .filter(p -> "confirmado".equals(p.getEstado()))
                        .mapToDouble(Pago::getMonto)
                        .sum();
                Platform.runLater(() -> {
                    lblTotalClientes.setText(String.valueOf(clientes.size()));
                    lblTotalPersonalActivo.setText(String.valueOf(personalActivo));
                    lblProyectosTotal.setText(String.valueOf(proyectos.size()));
                    lblProyectosPendientes.setText(String.valueOf(proyPendientes));
                    lblProyectosEnProceso.setText(String.valueOf(proyEnProceso));
                    lblProyectosFinalizados.setText(String.valueOf(proyFinalizados));
                    lblActividadesPendientes.setText(String.valueOf(actPendientes));
                    lblActividadesEnProceso.setText(String.valueOf(actEnProceso));
                    lblActividadesCompletadas.setText(String.valueOf(actCompletadas));
                    lblPagosConfirmados.setText(String.valueOf(pagosConfirmados));
                    lblPagosPendientes.setText(String.valueOf(pagosPendientes));
                    lblMontoConfirmado.setText(String.format(Locale.US, "$%,.2f", montoConfirmado));
                    lblMensaje.setText("");
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lblMensaje.setStyle("-fx-text-fill: red;");
                    lblMensaje.setText("Error al cargar indicadores: " + e.getMessage());
                });
            }
        }).start();
    }
    @FXML
    private void onVolverMenuClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tuempresa/menu_principal.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVolverMenu.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sistema de Gestión - Menú principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}